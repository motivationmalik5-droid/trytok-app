import React, { useState, useRef, useEffect, useCallback } from "react";
import { Heart, MessageCircle, Repeat2, Share2, Plus, Home, Compass, Send, User, Sun, Moon, Music2, CheckCircle2 } from "lucide-react";

// ---------------------------------------------------------------------------
// TryTok — foundational frontend
// Palette: near-black stage (#0A0A0F) / coral (#FF4D6D) / violet (#7C5CFC)
// Signature: "pulse disc" — a spinning sound-mark that ripples outward,
// standing in for the video's audio track on every card.
// ---------------------------------------------------------------------------

const POSTS = [
  {
    id: 1,
    user: "mira.codes",
    verified: true,
    caption: "rewriting my portfolio at 2am and it's actually going well 😭",
    tags: ["#buildinpublic", "#devlife"],
    sound: "original sound — mira.codes",
    gradient: "linear-gradient(160deg,#3A1C71,#7C5CFC 55%,#FF4D6D)",
    likes: "128.4K",
    comments: "2,431",
    shares: "9,120",
  },
  {
    id: 2,
    user: "kesh.travels",
    verified: false,
    caption: "hidden waterfall, 40 min hike, worth every step",
    tags: ["#hiddengem", "#hiking"],
    sound: "Golden Hour — slowed",
    gradient: "linear-gradient(160deg,#0F2027,#203A43 50%,#2C5364)",
    likes: "44.2K",
    comments: "812",
    shares: "1,204",
  },
  {
    id: 3,
    user: "noor.bakes",
    verified: true,
    caption: "3-ingredient pistachio cookies, no cap",
    tags: ["#recipe", "#pistachio", "#easybake"],
    sound: "original sound — noor.bakes",
    gradient: "linear-gradient(160deg,#654321,#B8860B 50%,#FF4D6D)",
    likes: "302.7K",
    comments: "5,903",
    shares: "22.1K",
  },
  {
    id: 4,
    user: "the.archive.fits",
    verified: false,
    caption: "y2k thrift haul pt. 4 — the denim jacket was $3",
    tags: ["#thrift", "#y2k", "#ootd"],
    sound: "Sped Up — club remix",
    gradient: "linear-gradient(160deg,#1A1A2E,#16213E 45%,#7C5CFC)",
    likes: "89.5K",
    comments: "1,742",
    shares: "3,390",
  },
];

const TABS = ["Following", "For You"];
const NAV = [
  { key: "home", label: "Home", icon: Home },
  { key: "discover", label: "Discover", icon: Compass },
  { key: "upload", label: "", icon: Plus },
  { key: "inbox", label: "Inbox", icon: Send },
  { key: "profile", label: "Profile", icon: User },
];

function PulseDisc({ playing }) {
  return (
    <div className="relative w-11 h-11 flex items-center justify-center">
      <span
        className={`absolute inset-0 rounded-full border border-white/40 ${
          playing ? "animate-ping-slow" : ""
        }`}
      />
      <div
        className={`w-9 h-9 rounded-full bg-gradient-to-br from-[#FF4D6D] to-[#7C5CFC] flex items-center justify-center shadow-lg shadow-black/30 ${
          playing ? "animate-spin-slow" : ""
        }`}
      >
        <Music2 size={14} className="text-white" strokeWidth={2.5} />
      </div>
    </div>
  );
}

function RailButton({ icon: Icon, label, active, onClick, filled }) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1 group"
      aria-label={label}
    >
      <span
        className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md transition-all duration-150 ${
          active
            ? "bg-[#FF4D6D] scale-105"
            : "bg-white/10 group-active:scale-90 group-hover:bg-white/20"
        }`}
      >
        <Icon
          size={22}
          className="text-white"
          fill={filled ? "white" : "none"}
          strokeWidth={2}
        />
      </span>
      <span className="text-[11px] font-semibold text-white/90 drop-shadow">
        {label}
      </span>
    </button>
  );
}

function VideoCard({ post, isActive }) {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);

  const toggleLike = () => {
    setLiked((l) => !l);
  };

  return (
    <section
      className="relative w-full h-full snap-start snap-always flex-shrink-0 overflow-hidden"
      style={{ background: post.gradient }}
    >
      {/* ambient motion layer — stands in for the actual video element */}
      <div
        className={`absolute inset-0 opacity-40 mix-blend-overlay ${
          isActive ? "animate-drift" : ""
        }`}
        style={{
          backgroundImage:
            "radial-gradient(circle at 30% 20%, rgba(255,255,255,0.5), transparent 40%), radial-gradient(circle at 80% 80%, rgba(255,255,255,0.3), transparent 45%)",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/0 to-black/30" />

      {/* caption block, bottom-left */}
      <div className="absolute left-4 right-20 bottom-24 text-white">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-9 h-9 rounded-full bg-white/20 border border-white/40 flex items-center justify-center font-bold text-sm">
            {post.user[0].toUpperCase()}
          </div>
          <span className="font-bold text-[15px] tracking-tight">
            @{post.user}
          </span>
          {post.verified && (
            <CheckCircle2 size={15} className="text-[#7C5CFC] fill-[#7C5CFC] text-white" />
          )}
          <button className="ml-1 text-[12px] font-bold border border-white/70 rounded-full px-2.5 py-[3px] active:scale-95 transition">
            Follow
          </button>
        </div>
        <p className="text-[14.5px] leading-snug font-medium mb-1.5">
          {post.caption}
        </p>
        <p className="text-[13px] font-semibold text-white/85">
          {post.tags.join("  ")}
        </p>
      </div>

      {/* right action rail */}
      <div className="absolute right-3 bottom-24 flex flex-col items-center gap-5">
        <RailButton
          icon={Heart}
          label={liked ? String(Number(likeCount.replace(/[^\d.]/g, "")) ) : post.likes}
          active={liked}
          filled={liked}
          onClick={toggleLike}
        />
        <RailButton icon={MessageCircle} label={post.comments} onClick={() => {}} />
        <RailButton icon={Repeat2} label="Repost" onClick={() => {}} />
        <RailButton icon={Share2} label={post.shares} onClick={() => {}} />
        <div className="pt-1">
          <PulseDisc playing={isActive} />
        </div>
      </div>

      {/* sound ticker */}
      <div className="absolute left-4 bottom-16 flex items-center gap-1.5 text-white/85 max-w-[60%]">
        <Music2 size={12} />
        <span className="text-[12px] font-medium truncate">{post.sound}</span>
      </div>
    </section>
  );
}

export default function TryTokApp() {
  const [tab, setTab] = useState("For You");
  const [dark, setDark] = useState(true);
  const [activeIdx, setActiveIdx] = useState(0);
  const [navKey, setNavKey] = useState("home");
  const containerRef = useRef(null);

  const onScroll = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    const idx = Math.round(el.scrollTop / el.clientHeight);
    setActiveIdx(idx);
  }, []);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, [onScroll]);

  const theme = dark
    ? { bg: "#0A0A0F", chrome: "bg-black/30", text: "text-white", sub: "text-white/60" }
    : { bg: "#FAFAF8", chrome: "bg-white/60", text: "text-[#14141A]", sub: "text-black/50" };

  return (
    <div
      className="relative w-full mx-auto overflow-hidden select-none"
      style={{
        maxWidth: 420,
        height: "100vh",
        background: theme.bg,
        fontFamily:
          "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, system-ui, sans-serif",
      }}
    >
      {/* top chrome: tabs + theme toggle */}
      <div
        className={`absolute top-0 left-0 right-0 z-20 flex items-center justify-center pt-4 pb-3 ${theme.chrome} backdrop-blur-sm`}
      >
        <div className="flex items-center gap-6">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`relative pb-1.5 text-[15px] font-bold tracking-tight transition-colors ${
                tab === t ? "text-white" : "text-white/50"
              }`}
              style={{ color: tab === t ? (dark ? "#fff" : "#14141A") : dark ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.4)" }}
            >
              {t}
              {tab === t && (
                <span className="absolute -bottom-0 left-1/2 -translate-x-1/2 w-6 h-[3px] rounded-full bg-[#FF4D6D]" />
              )}
            </button>
          ))}
        </div>
        <button
          onClick={() => setDark((d) => !d)}
          className="absolute right-4 w-8 h-8 rounded-full flex items-center justify-center bg-white/15 active:scale-90 transition"
          aria-label="Toggle theme"
        >
          {dark ? (
            <Sun size={15} className="text-white" />
          ) : (
            <Moon size={15} className="text-[#14141A]" />
          )}
        </button>
      </div>

      {/* feed */}
      <div
        ref={containerRef}
        className="w-full h-full overflow-y-scroll snap-y snap-mandatory"
        style={{ scrollbarWidth: "none" }}
      >
        {POSTS.map((post, i) => (
          <VideoCard key={post.id} post={post} isActive={i === activeIdx} />
        ))}
      </div>

      {/* bottom nav */}
      <div
        className={`absolute bottom-0 left-0 right-0 z-20 flex items-end justify-between px-5 pb-2.5 pt-2 ${theme.chrome} backdrop-blur-md border-t border-white/10`}
      >
        {NAV.map(({ key, label, icon: Icon }) =>
          key === "upload" ? (
            <button
              key={key}
              onClick={() => setNavKey(key)}
              className="w-11 h-8 -mt-1 rounded-lg bg-gradient-to-r from-[#FF4D6D] to-[#7C5CFC] flex items-center justify-center active:scale-90 transition shadow-lg shadow-black/30"
              aria-label="Upload"
            >
              <Plus size={20} className="text-white" strokeWidth={2.5} />
            </button>
          ) : (
            <button
              key={key}
              onClick={() => setNavKey(key)}
              className="flex flex-col items-center gap-1 pt-1 w-11"
            >
              <Icon
                size={22}
                strokeWidth={navKey === key ? 2.5 : 1.8}
                className={
                  navKey === key
                    ? "text-[#FF4D6D]"
                    : dark
                    ? "text-white/55"
                    : "text-black/40"
                }
              />
              <span
                className={`text-[10px] font-semibold ${
                  navKey === key
                    ? "text-[#FF4D6D]"
                    : dark
                    ? "text-white/55"
                    : "text-black/40"
                }`}
              >
                {label}
              </span>
            </button>
          )
        )}
      </div>

      <style>{`
        @keyframes spin-slow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .animate-spin-slow { animation: spin-slow 3.5s linear infinite; }
        @keyframes ping-slow { 0% { transform: scale(1); opacity: .6; } 75%,100% { transform: scale(1.6); opacity: 0; } }
        .animate-ping-slow { animation: ping-slow 2.2s cubic-bezier(0,0,0.2,1) infinite; }
        @keyframes drift { 0%,100% { transform: scale(1) translate(0,0); } 50% { transform: scale(1.08) translate(-2%,-1%); } }
        .animate-drift { animation: drift 9s ease-in-out infinite; }
        ::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}
