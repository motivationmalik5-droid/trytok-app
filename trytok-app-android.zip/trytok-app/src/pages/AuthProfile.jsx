import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  Mail, Phone, Lock, Eye, EyeOff, ChevronLeft, CheckCircle2,
  Settings, Grid3x3, Bookmark, Link as LinkIcon, Camera, ShieldCheck,
  Chrome, Apple as AppleIcon,
} from "lucide-react";

// ---------------------------------------------------------------------------
// TryTok — Auth + Profile system
// Same token system as Phase 1: bg #0A0A0F / coral #FF4D6D / violet #7C5CFC
// Signature: a live "session pill" that visualizes the access/refresh token
// lifecycle instead of hiding it — auth as something you can see working.
// ---------------------------------------------------------------------------

const ACCENT = "linear-gradient(90deg,#FF4D6D,#7C5CFC)";
const ACCESS_TTL = 12; // seconds — shortened for demo visibility
const REFRESH_TTL = 60;

// --- mock token engine ------------------------------------------------------
function makeToken(prefix) {
  const rand = Math.random().toString(36).slice(2, 10);
  return `${prefix}.${btoa(rand)}.${Date.now().toString(36)}`;
}

function useAuthSession() {
  const [session, setSession] = useState(null); // { access, refresh, accessExpiresAt, refreshExpiresAt }
  const [status, setStatus] = useState("idle"); // idle | active | refreshing | expired
  const timerRef = useRef(null);

  const login = useCallback(() => {
    const now = Date.now();
    setSession({
      access: makeToken("at"),
      refresh: makeToken("rt"),
      accessExpiresAt: now + ACCESS_TTL * 1000,
      refreshExpiresAt: now + REFRESH_TTL * 1000,
    });
    setStatus("active");
  }, []);

  const logout = useCallback(() => {
    setSession(null);
    setStatus("idle");
  }, []);

  const silentRefresh = useCallback(() => {
    setStatus("refreshing");
    setTimeout(() => {
      setSession((prev) => {
        if (!prev) return prev;
        if (Date.now() > prev.refreshExpiresAt) {
          setStatus("expired");
          return null;
        }
        setStatus("active");
        return {
          ...prev,
          access: makeToken("at"),
          accessExpiresAt: Date.now() + ACCESS_TTL * 1000,
        };
      });
    }, 700);
  }, []);

  useEffect(() => {
    if (!session) return;
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      const msLeft = session.accessExpiresAt - Date.now();
      if (msLeft <= 0 && status !== "refreshing") silentRefresh();
    }, 500);
    return () => clearInterval(timerRef.current);
  }, [session, status, silentRefresh]);

  return { session, status, login, logout };
}

// --- shared bits -------------------------------------------------------------
function FieldInput({ icon: Icon, ...props }) {
  return (
    <div className="flex items-center gap-2.5 bg-white/[0.06] border border-white/10 rounded-xl px-3.5 py-3 focus-within:border-[#7C5CFC]/70 transition-colors">
      <Icon size={17} className="text-white/40 shrink-0" />
      <input
        {...props}
        className="bg-transparent outline-none text-[14px] text-white placeholder-white/35 w-full font-medium"
      />
    </div>
  );
}

function PrimaryButton({ children, onClick, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full py-3.5 rounded-xl font-bold text-[14.5px] text-white active:scale-[0.98] transition disabled:opacity-40"
      style={{ background: ACCENT }}
    >
      {children}
    </button>
  );
}

function SocialButton({ icon: Icon, label, onClick }) {
  return (
    <button
      onClick={onClick}
      className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border border-white/15 bg-white/[0.04] active:scale-[0.97] transition"
    >
      <Icon size={16} className="text-white" />
      <span className="text-[13px] font-semibold text-white">{label}</span>
    </button>
  );
}

function SessionPill({ status, session }) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 500);
    return () => clearInterval(id);
  }, []);
  if (!session) return null;
  const secsLeft = Math.max(0, Math.ceil((session.accessExpiresAt - Date.now()) / 1000));
  const color =
    status === "refreshing" ? "#7C5CFC" : status === "expired" ? "#666" : "#3ED598";
  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 bg-black/70 backdrop-blur border border-white/10 rounded-full px-3.5 py-1.5">
      <span
        className="w-2 h-2 rounded-full"
        style={{ background: color, boxShadow: `0 0 8px ${color}` }}
      />
      <span className="text-[11px] font-semibold text-white/85">
        {status === "refreshing"
          ? "Refreshing access token…"
          : `Session active · access token expires in ${secsLeft}s`}
      </span>
    </div>
  );
}

// --- Auth screen ---------------------------------------------------------------
function AuthScreen({ onAuthed }) {
  const [mode, setMode] = useState("login"); // login | register
  const [method, setMethod] = useState("email"); // email | phone
  const [showPw, setShowPw] = useState(false);

  return (
    <div className="w-full h-full flex flex-col px-6 pt-16 pb-8 overflow-y-auto">
      <div className="mb-8">
        <div
          className="w-12 h-12 rounded-2xl mb-5 flex items-center justify-center font-black text-[20px] text-white"
          style={{ background: ACCENT }}
        >
          T
        </div>
        <h1 className="text-[26px] font-black text-white tracking-tight">
          {mode === "login" ? "Welcome back" : "Create your account"}
        </h1>
        <p className="text-[13.5px] text-white/45 mt-1.5 font-medium">
          {mode === "login"
            ? "Log in to keep watching what's next."
            : "Join TryTok — it takes less than a minute."}
        </p>
      </div>

      {/* method switch */}
      <div className="flex bg-white/[0.06] rounded-xl p-1 mb-5">
        {["email", "phone"].map((m) => (
          <button
            key={m}
            onClick={() => setMethod(m)}
            className={`flex-1 py-2 rounded-lg text-[13px] font-bold capitalize transition ${
              method === m ? "bg-white text-black" : "text-white/50"
            }`}
          >
            {m}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-3">
        {method === "email" ? (
          <FieldInput icon={Mail} type="email" placeholder="Email address" />
        ) : (
          <FieldInput icon={Phone} type="tel" placeholder="Phone number" />
        )}
        <div className="relative">
          <FieldInput
            icon={Lock}
            type={showPw ? "text" : "password"}
            placeholder="Password"
          />
          <button
            onClick={() => setShowPw((s) => !s)}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/40"
          >
            {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
        {mode === "register" && (
          <FieldInput icon={Lock} type="password" placeholder="Confirm password" />
        )}
      </div>

      {mode === "login" && (
        <button className="self-end mt-2.5 text-[12.5px] font-semibold text-white/50">
          Forgot password?
        </button>
      )}

      <div className="mt-6">
        <PrimaryButton onClick={onAuthed}>
          {mode === "login" ? "Log in" : "Sign up"}
        </PrimaryButton>
      </div>

      <div className="flex items-center gap-3 my-6">
        <div className="h-px bg-white/10 flex-1" />
        <span className="text-[11.5px] text-white/35 font-semibold">OR CONTINUE WITH</span>
        <div className="h-px bg-white/10 flex-1" />
      </div>

      <div className="flex gap-3">
        <SocialButton icon={Chrome} label="Google" onClick={onAuthed} />
        <SocialButton icon={AppleIcon} label="Apple" onClick={onAuthed} />
      </div>

      <p className="text-center text-[13px] text-white/45 font-medium mt-8">
        {mode === "login" ? "New to TryTok?" : "Already have an account?"}{" "}
        <button
          onClick={() => setMode(mode === "login" ? "register" : "login")}
          className="font-bold"
          style={{
            background: ACCENT,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          {mode === "login" ? "Sign up" : "Log in"}
        </button>
      </p>
    </div>
  );
}

// --- Profile pieces --------------------------------------------------------------
const VIDEOS = [
  "linear-gradient(160deg,#3A1C71,#7C5CFC)",
  "linear-gradient(160deg,#0F2027,#2C5364)",
  "linear-gradient(160deg,#654321,#FF4D6D)",
  "linear-gradient(160deg,#1A1A2E,#7C5CFC)",
  "linear-gradient(160deg,#2C0735,#FF4D6D)",
  "linear-gradient(160deg,#043927,#3ED598)",
];
const SAVED = [
  "linear-gradient(160deg,#1B1B2F,#7C5CFC)",
  "linear-gradient(160deg,#3E1929,#FF4D6D)",
  "linear-gradient(160deg,#0B2E33,#3ED598)",
];

function StatBlock({ value, label }) {
  return (
    <div className="flex flex-col items-center">
      <span className="text-[17px] font-black text-white leading-none">{value}</span>
      <span className="text-[11.5px] text-white/45 font-medium mt-1">{label}</span>
    </div>
  );
}

function VideoGrid({ items }) {
  if (items.length === 0) {
    return (
      <div className="py-16 text-center">
        <p className="text-white/35 text-[13px] font-medium">Nothing here yet.</p>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-3 gap-[2px] mt-3">
      {items.map((g, i) => (
        <div
          key={i}
          className="aspect-[9/13] relative"
          style={{ background: g }}
        >
          <span className="absolute bottom-1.5 left-1.5 text-[10.5px] font-bold text-white/90 drop-shadow">
            {(Math.random() * 900 + 100).toFixed(0)}K
          </span>
        </div>
      ))}
    </div>
  );
}

function ProfileScreen({ user, onEdit, onLogout }) {
  const [tab, setTab] = useState("videos");
  return (
    <div className="w-full h-full overflow-y-auto pb-10">
      <div className="flex items-center justify-between px-4 pt-5 pb-2">
        <span className="text-[15px] font-black text-white">@{user.username}</span>
        <button onClick={onEdit}>
          <Settings size={19} className="text-white/70" />
        </button>
      </div>

      <div className="flex flex-col items-center px-6 pt-3">
        <div
          className="w-20 h-20 rounded-full flex items-center justify-center text-[26px] font-black text-white border-2 border-white/10"
          style={{ background: ACCENT }}
        >
          {user.name[0].toUpperCase()}
        </div>
        <div className="flex items-center gap-1.5 mt-3">
          <span className="text-[16px] font-black text-white">{user.name}</span>
          {user.verified && (
            <ShieldCheck size={16} className="text-[#7C5CFC] fill-[#7C5CFC]/20" />
          )}
        </div>
        {user.verified && (
          <span className="text-[11px] font-bold text-[#7C5CFC] bg-[#7C5CFC]/10 rounded-full px-2.5 py-0.5 mt-1.5">
            Approved Creator
          </span>
        )}

        <div className="flex items-center gap-8 mt-5">
          <StatBlock value={user.following} label="Following" />
          <StatBlock value={user.followers} label="Followers" />
          <StatBlock value={user.likes} label="Likes" />
        </div>

        <p className="text-[13.5px] text-white/70 text-center mt-4 leading-snug max-w-[280px] font-medium">
          {user.bio}
        </p>
        {user.link && (
          <div className="flex items-center gap-1 mt-2 text-[12.5px] font-bold" style={{ color: "#7C5CFC" }}>
            <LinkIcon size={12} />
            {user.link}
          </div>
        )}

        <div className="flex gap-2.5 w-full mt-5">
          <button onClick={onEdit} className="flex-1 py-2.5 rounded-lg bg-white/10 text-white text-[13px] font-bold">
            Edit profile
          </button>
          <button onClick={onLogout} className="flex-1 py-2.5 rounded-lg bg-white/10 text-white text-[13px] font-bold">
            Log out
          </button>
        </div>
      </div>

      <div className="flex border-t border-white/10 mt-6">
        {[
          { key: "videos", icon: Grid3x3 },
          { key: "saved", icon: Bookmark },
        ].map(({ key, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`flex-1 flex items-center justify-center py-3 border-b-2 transition ${
              tab === key ? "border-white" : "border-transparent"
            }`}
          >
            <Icon size={18} className={tab === key ? "text-white" : "text-white/35"} />
          </button>
        ))}
      </div>

      <VideoGrid items={tab === "videos" ? VIDEOS : SAVED} />
    </div>
  );
}

function EditProfileScreen({ user, onSave, onBack }) {
  const [form, setForm] = useState(user);
  return (
    <div className="w-full h-full overflow-y-auto">
      <div className="flex items-center gap-3 px-4 pt-5 pb-4">
        <button onClick={onBack}>
          <ChevronLeft size={22} className="text-white" />
        </button>
        <span className="text-[15.5px] font-black text-white">Edit profile</span>
      </div>

      <div className="flex flex-col items-center py-4">
        <div className="relative">
          <div
            className="w-20 h-20 rounded-full flex items-center justify-center text-[24px] font-black text-white"
            style={{ background: ACCENT }}
          >
            {form.name[0]?.toUpperCase() || "?"}
          </div>
          <span className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-white flex items-center justify-center border-2 border-black">
            <Camera size={13} className="text-black" />
          </span>
        </div>
        <span className="text-[12.5px] font-bold text-[#7C5CFC] mt-2.5">Change photo</span>
      </div>

      <div className="px-5 flex flex-col gap-4 mt-2">
        {[
          { key: "name", label: "Name" },
          { key: "username", label: "Username" },
          { key: "bio", label: "Bio" },
          { key: "link", label: "Link" },
        ].map(({ key, label }) => (
          <div key={key}>
            <label className="text-[11.5px] font-bold text-white/40 uppercase tracking-wide">
              {label}
            </label>
            {key === "bio" ? (
              <textarea
                value={form[key]}
                maxLength={120}
                onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                rows={3}
                className="w-full mt-1.5 bg-white/[0.06] border border-white/10 rounded-xl px-3.5 py-2.5 text-white text-[14px] font-medium outline-none focus:border-[#7C5CFC]/70 resize-none"
              />
            ) : (
              <input
                value={form[key]}
                onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                className="w-full mt-1.5 bg-white/[0.06] border border-white/10 rounded-xl px-3.5 py-2.5 text-white text-[14px] font-medium outline-none focus:border-[#7C5CFC]/70"
              />
            )}
          </div>
        ))}
      </div>

      <div className="px-5 mt-7">
        <PrimaryButton onClick={() => onSave(form)}>Save changes</PrimaryButton>
      </div>
    </div>
  );
}

// --- App shell ------------------------------------------------------------------
export default function TryTokAuthProfile() {
  const { session, status, login, logout } = useAuthSession();
  const [screen, setScreen] = useState("auth"); // auth | profile | edit
  const [user, setUser] = useState({
    name: "Mira Chen",
    username: "mira.codes",
    bio: "frontend dev · building in public · she/her",
    link: "mira.dev",
    followers: "12.4K",
    following: "384",
    likes: "128.4K",
    verified: true,
  });

  const handleAuthed = () => {
    login();
    setScreen("profile");
  };
  const handleLogout = () => {
    logout();
    setScreen("auth");
  };

  return (
    <div
      className="relative w-full mx-auto overflow-hidden"
      style={{
        maxWidth: 420,
        height: "100vh",
        background: "#0A0A0F",
        fontFamily:
          "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, system-ui, sans-serif",
      }}
    >
      {screen !== "auth" && <SessionPill status={status} session={session} />}

      {screen === "auth" && <AuthScreen onAuthed={handleAuthed} />}
      {screen === "profile" && (
        <ProfileScreen user={user} onEdit={() => setScreen("edit")} onLogout={handleLogout} />
      )}
      {screen === "edit" && (
        <EditProfileScreen
          user={user}
          onBack={() => setScreen("profile")}
          onSave={(f) => {
            setUser(f);
            setScreen("profile");
          }}
        />
      )}
    </div>
  );
}
