import React, { useState, useEffect, useRef } from "react";
import {
  Eye, X, Send, Gift, Coins, ShieldCheck, MicOff, UserX, LogOut,
  Crown, ChevronLeft, Wallet as WalletIcon, TrendingUp, ArrowDownToLine,
  CreditCard, Building2, ChevronRight, Sparkles, MoreVertical,
} from "lucide-react";

// ---------------------------------------------------------------------------
// TryTok — Live Streaming + Monetization
// Same system: bg #0A0A0F / coral #FF4D6D / violet #7C5CFC
// Signature: gifts render as rising "coin trails" over the stream —
// the same coin glyph reappears in Wallet/Earnings, tying spend to earn.
// ---------------------------------------------------------------------------

const ACCENT = "linear-gradient(90deg,#FF4D6D,#7C5CFC)";

// --- Live stream ------------------------------------------------------------------
const LIVE_COMMENTS = [
  { user: "kesh.travels", text: "let's gooo 🔥" },
  { user: "noor.bakes", text: "just joined!" },
  { user: "sam.codes", text: "sent 100 coins 🎁" },
  { user: "the.archive.fits", text: "this is fire" },
];

const RANKINGS = [
  { user: "the.archive.fits", coins: "42.1K" },
  { user: "kesh.travels", coins: "28.4K" },
  { user: "sam.codes", coins: "11.9K" },
];

const GIFTS = [
  { name: "Rose", cost: 10, icon: "🌹" },
  { name: "Heart", cost: 50, icon: "💗" },
  { name: "Crown", cost: 500, icon: "👑" },
  { name: "Rocket", cost: 2000, icon: "🚀" },
  { name: "Galaxy", cost: 5000, icon: "🌌" },
  { name: "Diamond", cost: 10000, icon: "💎" },
];

const VIEWERS = [
  { user: "kesh.travels", role: "viewer" },
  { user: "noor.bakes", role: "moderator" },
  { user: "sam.codes", role: "viewer" },
  { user: "the.archive.fits", role: "viewer" },
];

function GiftSheet({ onClose, onSend, coinBalance }) {
  return (
    <div className="fixed inset-0 z-40 flex items-end" style={{ maxWidth: 420, margin: "0 auto" }}>
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full bg-[#131318] rounded-t-2xl px-4 pt-4 pb-6">
        <div className="w-9 h-1 bg-white/20 rounded-full mx-auto mb-4" />
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[14px] font-black text-white">Send a gift</h3>
          <span className="flex items-center gap-1 text-[12.5px] font-bold text-white/70">
            <Coins size={13} className="text-[#FFB020]" /> {coinBalance.toLocaleString()}
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2.5">
          {GIFTS.map((g) => (
            <button
              key={g.name}
              onClick={() => onSend(g)}
              className="flex flex-col items-center gap-1 bg-white/[0.05] rounded-xl py-3 active:scale-95 transition"
            >
              <span className="text-[26px]">{g.icon}</span>
              <span className="text-[11px] font-bold text-white">{g.name}</span>
              <span className="flex items-center gap-1 text-[10.5px] font-semibold text-[#FFB020]">
                <Coins size={10} /> {g.cost}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function ModeratorSheet({ onClose }) {
  const [viewers, setViewers] = useState(VIEWERS);
  const act = (user, action) => {
    if (action === "kick") setViewers((v) => v.filter((x) => x.user !== user));
    else setViewers((v) => v.map((x) => (x.user === user ? { ...x, [action]: true } : x)));
  };
  return (
    <div className="fixed inset-0 z-40 flex items-end" style={{ maxWidth: 420, margin: "0 auto" }}>
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full bg-[#131318] rounded-t-2xl px-4 pt-4 pb-6 max-h-[70%] overflow-y-auto">
        <div className="w-9 h-1 bg-white/20 rounded-full mx-auto mb-4" />
        <h3 className="text-[14px] font-black text-white mb-3">Moderation · {viewers.length} in room</h3>
        {viewers.map((v) => (
          <div key={v.user} className="flex items-center gap-3 py-2.5 border-b border-white/5 last:border-0">
            <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-white text-[13px]" style={{ background: ACCENT }}>
              {v.user[0].toUpperCase()}
            </div>
            <div className="flex-1">
              <p className="text-[13px] font-bold text-white">@{v.user}</p>
              <p className="text-[11px] text-white/40">{v.role === "moderator" ? "Moderator" : "Viewer"}</p>
            </div>
            <button onClick={() => act(v.user, "muted")} className={`w-7 h-7 rounded-full flex items-center justify-center ${v.muted ? "bg-[#FF4D6D]/30" : "bg-white/10"}`}>
              <MicOff size={13} className={v.muted ? "text-[#FF4D6D]" : "text-white/60"} />
            </button>
            <button onClick={() => act(v.user, "blocked")} className={`w-7 h-7 rounded-full flex items-center justify-center ${v.blocked ? "bg-[#FF4D6D]/30" : "bg-white/10"}`}>
              <UserX size={13} className={v.blocked ? "text-[#FF4D6D]" : "text-white/60"} />
            </button>
            <button onClick={() => act(v.user, "kick")} className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center">
              <LogOut size={13} className="text-white/60" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function LiveStream({ coinBalance, spendCoins }) {
  const [comments, setComments] = useState(LIVE_COMMENTS);
  const [floatGifts, setFloatGifts] = useState([]);
  const [giftOpen, setGiftOpen] = useState(false);
  const [modOpen, setModOpen] = useState(false);
  const [viewers, setViewers] = useState(1284);
  const scrollRef = useRef(null);

  useEffect(() => {
    const id = setInterval(() => setViewers((v) => v + Math.floor(Math.random() * 5 - 1)), 2500);
    return () => clearInterval(id);
  }, []);

  const sendGift = (g) => {
    if (coinBalance < g.cost) return;
    spendCoins(g.cost);
    setGiftOpen(false);
    const fid = Date.now();
    setFloatGifts((f) => [...f, { id: fid, icon: g.icon, left: 20 + Math.random() * 60 }]);
    setComments((c) => [...c, { user: "you", text: `sent ${g.name} ${g.icon}` }]);
    setTimeout(() => setFloatGifts((f) => f.filter((x) => x.id !== fid)), 2200);
  };

  return (
    <div className="relative w-full h-full overflow-hidden" style={{ background: "linear-gradient(160deg,#1A1A2E,#3A1C71 55%,#7C5CFC)" }}>
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/70" />

      {/* top bar */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-black/40 rounded-full pl-1 pr-3 py-1">
            <div className="w-7 h-7 rounded-full flex items-center justify-center font-bold text-white text-[11px]" style={{ background: ACCENT }}>
              M
            </div>
            <span className="text-[12px] font-bold text-white">mira.codes</span>
          </div>
          <span className="text-[10.5px] font-black text-white bg-[#FF4D6D] rounded-full px-2 py-1">LIVE</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 bg-black/40 rounded-full px-2.5 py-1 text-[11.5px] font-bold text-white">
            <Eye size={12} /> {viewers.toLocaleString()}
          </span>
          <button onClick={() => setModOpen(true)} className="w-7 h-7 rounded-full bg-black/40 flex items-center justify-center">
            <MoreVertical size={14} className="text-white" />
          </button>
        </div>
      </div>

      {/* co-host split */}
      <div className="absolute top-16 right-4 w-20 h-28 rounded-xl overflow-hidden border-2 border-white/30 z-10" style={{ background: "linear-gradient(160deg,#0F2027,#2C5364)" }}>
        <span className="absolute bottom-1 left-1 text-[9.5px] font-bold text-white bg-black/40 rounded px-1.5">co-host</span>
      </div>

      {/* rankings */}
      <div className="absolute top-16 left-4 flex flex-col gap-1.5 z-10">
        {RANKINGS.map((r, i) => (
          <div key={r.user} className="flex items-center gap-1.5 bg-black/35 rounded-full pl-1 pr-2.5 py-1">
            <Crown size={11} className={i === 0 ? "text-[#FFD700]" : "text-white/50"} />
            <span className="text-[10.5px] font-bold text-white">@{r.user}</span>
            <span className="text-[10px] font-semibold text-[#FFB020]">{r.coins}</span>
          </div>
        ))}
      </div>

      {/* floating gifts */}
      {floatGifts.map((g) => (
        <span
          key={g.id}
          className="absolute bottom-32 text-[34px] animate-rise z-10"
          style={{ left: `${g.left}%` }}
        >
          {g.icon}
        </span>
      ))}

      {/* live comments */}
      <div ref={scrollRef} className="absolute bottom-24 left-4 right-24 flex flex-col gap-1.5 max-h-40 overflow-hidden z-10">
        {comments.slice(-6).map((c, i) => (
          <div key={i} className="text-[12.5px] text-white font-medium bg-black/25 rounded-lg px-2.5 py-1 w-fit max-w-full">
            <span className="font-bold text-[#7C5CFC]">@{c.user}</span> {c.text}
          </div>
        ))}
      </div>

      {/* bottom input */}
      <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2.5 z-10">
        <input
          placeholder="Say something…"
          className="flex-1 bg-black/40 border border-white/15 rounded-full px-4 py-2.5 text-[13px] text-white outline-none placeholder-white/40"
        />
        <button
          onClick={() => setGiftOpen(true)}
          className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
          style={{ background: ACCENT }}
        >
          <Gift size={18} className="text-white" />
        </button>
      </div>

      {giftOpen && <GiftSheet onClose={() => setGiftOpen(false)} onSend={sendGift} coinBalance={coinBalance} />}
      {modOpen && <ModeratorSheet onClose={() => setModOpen(false)} />}

      <style>{`
        @keyframes rise { 0% { transform: translateY(0) scale(0.6); opacity: 0; } 15% { opacity: 1; transform: scale(1); } 100% { transform: translateY(-220px) scale(1.1); opacity: 0; } }
        .animate-rise { animation: rise 2.2s ease-out forwards; }
      `}</style>
    </div>
  );
}

// --- Coins purchase ---------------------------------------------------------------
const COIN_PACKS = [
  { coins: 100, price: "$0.99" },
  { coins: 500, price: "$4.99" },
  { coins: 1200, price: "$9.99", tag: "Popular" },
  { coins: 2500, price: "$19.99" },
  { coins: 6500, price: "$49.99", tag: "Best value" },
  { coins: 14000, price: "$99.99" },
];

function CoinsPage({ coinBalance, addCoins }) {
  return (
    <div className="w-full h-full overflow-y-auto pb-10 px-4 pt-5">
      <div className="flex items-center gap-2 mb-1">
        <Coins size={18} className="text-[#FFB020]" />
        <h1 className="text-[17px] font-black text-white">Get coins</h1>
      </div>
      <p className="text-[12.5px] text-white/45 font-medium mb-5">
        Current balance: <span className="font-bold text-white">{coinBalance.toLocaleString()} coins</span>
      </p>
      <div className="grid grid-cols-2 gap-3">
        {COIN_PACKS.map((p) => (
          <button
            key={p.coins}
            onClick={() => addCoins(p.coins)}
            className="relative flex flex-col items-center gap-1.5 bg-white/[0.05] border border-white/10 rounded-xl py-4 active:scale-[0.97] transition"
          >
            {p.tag && (
              <span className="absolute -top-2 text-[9.5px] font-black text-white rounded-full px-2 py-0.5" style={{ background: ACCENT }}>
                {p.tag}
              </span>
            )}
            <Coins size={20} className="text-[#FFB020]" />
            <span className="text-[15px] font-black text-white">{p.coins.toLocaleString()}</span>
            <span className="text-[12px] font-bold text-white/60">{p.price}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// --- Wallet ------------------------------------------------------------------------
const TRANSACTIONS = [
  { id: 1, type: "purchase", label: "Purchased 1,200 coins", amount: "+1,200", time: "Today, 2:14 PM" },
  { id: 2, type: "gift", label: "Sent Rocket to @sam.codes", amount: "-2,000", time: "Today, 1:02 PM" },
  { id: 3, type: "earning", label: "Gift received during live", amount: "+8,400", time: "Yesterday" },
  { id: 4, type: "withdraw", label: "Withdrawal to PayPal", amount: "-15,000", time: "Jul 1" },
  { id: 5, type: "purchase", label: "Purchased 500 coins", amount: "+500", time: "Jun 28" },
];

function WalletPage({ coinBalance, onGoWithdraw }) {
  return (
    <div className="w-full h-full overflow-y-auto pb-10 px-4 pt-5">
      <div className="flex items-center gap-2 mb-4">
        <WalletIcon size={18} className="text-white" />
        <h1 className="text-[17px] font-black text-white">Wallet</h1>
      </div>

      <div className="rounded-2xl p-5 mb-5" style={{ background: ACCENT }}>
        <p className="text-[12px] font-semibold text-white/80">Coin balance</p>
        <p className="text-[28px] font-black text-white mt-1">{coinBalance.toLocaleString()}</p>
        <button onClick={onGoWithdraw} className="mt-3 bg-white/20 text-white text-[12.5px] font-bold rounded-full px-4 py-1.5">
          Withdraw earnings
        </button>
      </div>

      <p className="text-[12.5px] font-bold text-white/45 mb-2.5">Transaction history</p>
      <div className="flex flex-col divide-y divide-white/5">
        {TRANSACTIONS.map((t) => (
          <div key={t.id} className="flex items-center justify-between py-3">
            <div>
              <p className="text-[13px] font-semibold text-white">{t.label}</p>
              <p className="text-[11px] text-white/40 mt-0.5">{t.time}</p>
            </div>
            <span className={`text-[13.5px] font-black ${t.amount.startsWith("+") ? "text-[#3ED598]" : "text-[#FF4D6D]"}`}>
              {t.amount}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// --- Creator earnings dashboard -----------------------------------------------------
const EARNINGS_BREAKDOWN = [
  { label: "Live gifts", value: 62, color: "#FF4D6D" },
  { label: "Video gifts", value: 23, color: "#7C5CFC" },
  { label: "Creator fund", value: 15, color: "#3ED598" },
];

function EarningsPage({ onGoWithdraw }) {
  return (
    <div className="w-full h-full overflow-y-auto pb-10 px-4 pt-5">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp size={18} className="text-white" />
        <h1 className="text-[17px] font-black text-white">Creator earnings</h1>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-5">
        <div className="bg-white/[0.05] rounded-xl p-4">
          <p className="text-[11.5px] text-white/45 font-semibold">This week</p>
          <p className="text-[20px] font-black text-white mt-1">$482.90</p>
          <p className="text-[11px] text-[#3ED598] font-bold mt-0.5">+18.2%</p>
        </div>
        <div className="bg-white/[0.05] rounded-xl p-4">
          <p className="text-[11.5px] text-white/45 font-semibold">All time</p>
          <p className="text-[20px] font-black text-white mt-1">$6,214.10</p>
          <p className="text-[11px] text-white/35 font-medium mt-0.5">since Jan 2026</p>
        </div>
      </div>

      {/* simple 7-day bar chart */}
      <div className="bg-white/[0.05] rounded-xl p-4 mb-5">
        <p className="text-[12px] font-bold text-white/60 mb-3">Last 7 days</p>
        <div className="flex items-end gap-2 h-24">
          {[40, 65, 30, 80, 55, 95, 70].map((h, i) => (
            <div key={i} className="flex-1 rounded-t-md" style={{ height: `${h}%`, background: ACCENT }} />
          ))}
        </div>
        <div className="flex justify-between mt-1.5">
          {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
            <span key={i} className="text-[10px] text-white/35 font-semibold flex-1 text-center">{d}</span>
          ))}
        </div>
      </div>

      <p className="text-[12.5px] font-bold text-white/45 mb-2.5">Earnings breakdown</p>
      <div className="flex flex-col gap-2.5 mb-5">
        {EARNINGS_BREAKDOWN.map((b) => (
          <div key={b.label}>
            <div className="flex justify-between mb-1">
              <span className="text-[12.5px] font-semibold text-white">{b.label}</span>
              <span className="text-[12.5px] font-bold text-white/60">{b.value}%</span>
            </div>
            <div className="h-2 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${b.value}%`, background: b.color }} />
            </div>
          </div>
        ))}
      </div>

      <button onClick={onGoWithdraw} className="w-full py-3.5 rounded-xl font-bold text-[14.5px] text-white" style={{ background: ACCENT }}>
        Withdraw earnings
      </button>
    </div>
  );
}

// --- Withdrawal ---------------------------------------------------------------------
const METHODS = [
  { key: "stripe", label: "Stripe", icon: CreditCard, note: "1–2 business days" },
  { key: "paypal", label: "PayPal", icon: WalletIcon, note: "Instant" },
  { key: "wise", label: "Wise", icon: Send, note: "1–3 business days, best FX rate" },
  { key: "bank", label: "Bank transfer", icon: Building2, note: "3–5 business days" },
];

function WithdrawPage({ onBack }) {
  const [method, setMethod] = useState("stripe");
  const [amount, setAmount] = useState("");
  const [done, setDone] = useState(false);

  if (done) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center px-8 text-center">
        <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4" style={{ background: ACCENT }}>
          <ArrowDownToLine size={26} className="text-white" />
        </div>
        <h2 className="text-[17px] font-black text-white mb-1.5">Withdrawal requested</h2>
        <p className="text-[13px] text-white/50 font-medium">
          ${amount || "0.00"} is on its way via {METHODS.find((m) => m.key === method).label}.
        </p>
        <button onClick={onBack} className="mt-6 text-[13px] font-bold text-[#7C5CFC]">Back to wallet</button>
      </div>
    );
  }

  return (
    <div className="w-full h-full overflow-y-auto pb-10 px-4 pt-5">
      <div className="flex items-center gap-2.5 mb-4">
        <button onClick={onBack}><ChevronLeft size={20} className="text-white" /></button>
        <h1 className="text-[16px] font-black text-white">Withdraw</h1>
      </div>

      <label className="text-[11.5px] font-bold text-white/40 uppercase tracking-wide">Amount (USD)</label>
      <input
        value={amount}
        onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
        placeholder="0.00"
        className="w-full mt-1.5 mb-5 bg-white/[0.06] border border-white/10 rounded-xl px-3.5 py-3 text-white text-[16px] font-bold outline-none focus:border-[#7C5CFC]/70"
      />

      <p className="text-[12.5px] font-bold text-white/45 mb-2.5">Withdrawal method</p>
      <div className="flex flex-col gap-2 mb-6">
        {METHODS.map((m) => (
          <button
            key={m.key}
            onClick={() => setMethod(m.key)}
            className="flex items-center gap-3 bg-white/[0.05] rounded-xl px-3.5 py-3"
            style={method === m.key ? { outline: "2px solid #FF4D6D", outlineOffset: -2 } : {}}
          >
            <m.icon size={18} className="text-white/70" />
            <div className="flex-1 text-left">
              <p className="text-[13.5px] font-bold text-white">{m.label}</p>
              <p className="text-[11px] text-white/40">{m.note}</p>
            </div>
            {method === m.key && <Sparkles size={14} className="text-[#FF4D6D]" />}
          </button>
        ))}
      </div>

      <button
        onClick={() => setDone(true)}
        disabled={!amount}
        className="w-full py-3.5 rounded-xl font-bold text-[14.5px] text-white disabled:opacity-40"
        style={{ background: ACCENT }}
      >
        Confirm withdrawal
      </button>
    </div>
  );
}

// --- shell -----------------------------------------------------------------------
export default function TryTokLiveMonetization() {
  const [view, setView] = useState("live");
  const [coinBalance, setCoinBalance] = useState(3200);

  const tabs = [
    { key: "live", label: "Live" },
    { key: "coins", label: "Coins" },
    { key: "wallet", label: "Wallet" },
    { key: "earnings", label: "Earnings" },
  ];

  return (
    <div
      className="relative w-full mx-auto overflow-hidden"
      style={{
        maxWidth: 420,
        height: "100vh",
        background: "#0A0A0F",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, system-ui, sans-serif",
      }}
    >
      {view !== "withdraw" && (
        <div className="absolute top-0 left-0 right-0 z-20 flex justify-center gap-1.5 pt-3 pb-2 bg-[#0A0A0F]/80 backdrop-blur border-b border-white/5">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setView(t.key)}
              className="px-3 py-1.5 rounded-full text-[11.5px] font-bold transition"
              style={view === t.key ? { background: ACCENT, color: "white" } : { background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.4)" }}
            >
              {t.label}
            </button>
          ))}
        </div>
      )}
      <div className={view === "live" ? "h-full" : "pt-12 h-full"}>
        {view === "live" && <LiveStream coinBalance={coinBalance} spendCoins={(n) => setCoinBalance((b) => b - n)} />}
        {view === "coins" && <CoinsPage coinBalance={coinBalance} addCoins={(n) => setCoinBalance((b) => b + n)} />}
        {view === "wallet" && <WalletPage coinBalance={coinBalance} onGoWithdraw={() => setView("withdraw")} />}
        {view === "earnings" && <EarningsPage onGoWithdraw={() => setView("withdraw")} />}
        {view === "withdraw" && <WithdrawPage onBack={() => setView("wallet")} />}
      </div>
    </div>
  );
}
