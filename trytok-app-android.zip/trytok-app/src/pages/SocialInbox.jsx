import React, { useState, useRef, useEffect } from "react";
import {
  Heart, MessageCircle, Send, Mic, Image as ImageIcon, ChevronLeft,
  MoreHorizontal, Flag, UserX, X, Check, CheckCheck, Play, Users as UsersIcon,
  Bell, UserPlus, AtSign, Repeat2, Bookmark, Circle,
} from "lucide-react";

// ---------------------------------------------------------------------------
// TryTok — Social interactions + Messaging + Activity
// Same system: bg #0A0A0F / coral #FF4D6D / violet #7C5CFC
// Signature: a shared "reply thread spine" — a thin connecting line ties
// nested comment replies and chat message groups together visually.
// ---------------------------------------------------------------------------

const ACCENT = "linear-gradient(90deg,#FF4D6D,#7C5CFC)";

// --- moderation sheet (report / block) — shared by comments + chats ------------
function ModerationSheet({ target, onClose }) {
  if (!target) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-end" style={{ maxWidth: 420, margin: "0 auto" }}>
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative w-full bg-[#131318] rounded-t-2xl px-4 pt-4 pb-6">
        <div className="w-9 h-1 bg-white/20 rounded-full mx-auto mb-4" />
        <p className="text-center text-[12.5px] text-white/40 font-medium mb-2">@{target}</p>
        <button className="flex items-center gap-3 w-full py-3 border-b border-white/5">
          <Flag size={17} className="text-white/70" />
          <span className="text-[13.5px] font-semibold text-white">Report</span>
        </button>
        <button className="flex items-center gap-3 w-full py-3">
          <UserX size={17} className="text-[#FF4D6D]" />
          <span className="text-[13.5px] font-semibold text-[#FF4D6D]">Block user</span>
        </button>
      </div>
    </div>
  );
}

// --- Comments panel -------------------------------------------------------------
const COMMENTS = [
  {
    id: 1, user: "kesh.travels", text: "the transition at 0:08 is insane 😭", likes: 342, liked: false,
    replies: [
      { id: 11, user: "mira.codes", text: "right?? I rewatched it like 5 times", likes: 12, liked: false },
      { id: 12, user: "noor.bakes", text: "same energy as that other clip", likes: 3, liked: false },
    ],
  },
  {
    id: 2, user: "the.archive.fits", text: "what editing app is this", likes: 88, liked: false,
    replies: [
      { id: 21, user: "mira.codes", text: "CapCut + a LUT pack, linked in bio", likes: 40, liked: false },
    ],
  },
  { id: 3, user: "sam.codes", text: "underrated creator fr", likes: 210, liked: false, replies: [] },
];

function CommentRow({ c, onLike, onReport, depth = 0 }) {
  const [showReplies, setShowReplies] = useState(depth === 0);
  return (
    <div className={depth > 0 ? "pl-8 relative" : ""}>
      {depth > 0 && (
        <span className="absolute left-3 top-0 bottom-0 w-px bg-white/10" />
      )}
      <div className="flex gap-2.5 py-2.5">
        <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-[12px] shrink-0" style={{ background: ACCENT }}>
          {c.user[0].toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[12px] font-bold text-white/60">@{c.user}</p>
          <p className="text-[13.5px] text-white font-medium leading-snug">{c.text}</p>
          <div className="flex items-center gap-4 mt-1">
            <span className="text-[11px] text-white/35 font-semibold">2h</span>
            <button className="text-[11px] text-white/35 font-bold">Reply</button>
            <button onClick={() => onReport(c.user)}>
              <MoreHorizontal size={13} className="text-white/30" />
            </button>
          </div>
          {c.replies?.length > 0 && depth === 0 && (
            <button
              onClick={() => setShowReplies((s) => !s)}
              className="text-[11.5px] font-bold text-white/45 mt-1.5 flex items-center gap-1.5"
            >
              <span className="w-4 h-px bg-white/25" />
              {showReplies ? "Hide" : "View"} {c.replies.length} {c.replies.length === 1 ? "reply" : "replies"}
            </button>
          )}
        </div>
        <button onClick={() => onLike(c.id)} className="flex flex-col items-center gap-0.5 pt-1">
          <Heart size={14} fill={c.liked ? "#FF4D6D" : "none"} className={c.liked ? "text-[#FF4D6D]" : "text-white/40"} />
          <span className="text-[10px] text-white/35 font-semibold">{c.likes}</span>
        </button>
      </div>
      {showReplies &&
        c.replies?.map((r) => (
          <CommentRow key={r.id} c={r} onLike={onLike} onReport={onReport} depth={depth + 1} />
        ))}
    </div>
  );
}

function CommentsPanel() {
  const [comments, setComments] = useState(COMMENTS);
  const [reportTarget, setReportTarget] = useState(null);
  const [saved, setSaved] = useState(false);
  const [draft, setDraft] = useState("");

  const toggleLike = (id) => {
    const flip = (list) =>
      list.map((c) =>
        c.id === id
          ? { ...c, liked: !c.liked, likes: c.liked ? c.likes - 1 : c.likes + 1 }
          : { ...c, replies: c.replies ? flip(c.replies) : c.replies }
      );
    setComments((prev) => flip(prev));
  };

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <span className="text-[14px] font-black text-white">1,284 comments</span>
        <button onClick={() => setSaved((s) => !s)} className="flex items-center gap-1.5">
          <Bookmark size={16} fill={saved ? "#7C5CFC" : "none"} className={saved ? "text-[#7C5CFC]" : "text-white/60"} />
          <span className="text-[12px] font-bold text-white/60">{saved ? "Saved" : "Save"}</span>
        </button>
      </div>
      <div className="flex-1 overflow-y-auto px-4">
        {comments.map((c) => (
          <CommentRow key={c.id} c={c} onLike={toggleLike} onReport={setReportTarget} />
        ))}
      </div>
      <div className="flex items-center gap-2.5 px-4 py-3 border-t border-white/10">
        <div className="w-7 h-7 rounded-full shrink-0" style={{ background: ACCENT }} />
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Add comment…"
          className="flex-1 bg-white/[0.06] border border-white/10 rounded-full px-3.5 py-2 text-[13px] text-white outline-none placeholder-white/35"
        />
        <button style={{ background: ACCENT }} className="w-8 h-8 rounded-full flex items-center justify-center shrink-0">
          <Send size={14} className="text-white" />
        </button>
      </div>
      <ModerationSheet target={reportTarget} onClose={() => setReportTarget(null)} />
    </div>
  );
}

// --- Inbox: chat list --------------------------------------------------------------
const CHATS = [
  { id: 1, name: "kesh.travels", group: false, online: true, last: "sent a voice message", time: "2m", unread: 2, typing: true },
  { id: 2, name: "Trip planning 🏔️", group: true, members: ["kesh.travels", "noor.bakes", "sam.codes"], online: false, last: "sam: count me in!", time: "18m", unread: 0, typing: false },
  { id: 3, name: "noor.bakes", group: false, online: false, last: "photo", time: "1h", unread: 0, typing: false },
  { id: 4, name: "the.archive.fits", group: false, online: true, last: "thrift haul link ↓", time: "3h", unread: 1, typing: false },
];

function ChatListRow({ chat, onOpen }) {
  return (
    <button onClick={() => onOpen(chat)} className="flex items-center gap-3 w-full py-3">
      <div className="relative shrink-0">
        <div
          className="w-12 h-12 rounded-full flex items-center justify-center font-bold text-white text-[15px]"
          style={{ background: chat.group ? "linear-gradient(160deg,#7C5CFC,#3A1C71)" : ACCENT }}
        >
          {chat.group ? <UsersIcon size={18} /> : chat.name[0].toUpperCase()}
        </div>
        {!chat.group && chat.online && (
          <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#3ED598] border-2 border-[#0A0A0F]" />
        )}
      </div>
      <div className="flex-1 min-w-0 text-left">
        <p className="text-[13.5px] font-bold text-white truncate">{chat.name}</p>
        <p className={`text-[12px] truncate ${chat.typing ? "text-[#7C5CFC] font-semibold" : "text-white/45 font-medium"}`}>
          {chat.typing ? "typing…" : chat.last}
        </p>
      </div>
      <div className="flex flex-col items-end gap-1 shrink-0">
        <span className="text-[11px] text-white/35 font-medium">{chat.time}</span>
        {chat.unread > 0 && (
          <span className="w-4.5 h-4.5 min-w-[18px] rounded-full bg-[#FF4D6D] text-white text-[10px] font-bold flex items-center justify-center">
            {chat.unread}
          </span>
        )}
      </div>
    </button>
  );
}

// --- Inbox: chat thread --------------------------------------------------------------
const THREAD = [
  { id: 1, mine: false, type: "text", text: "yo did you see the waterfall spot I posted" },
  { id: 2, mine: true, type: "text", text: "yes!! adding it to my list rn", read: true },
  { id: 3, mine: false, type: "image", caption: "here's the trail map" },
  { id: 4, mine: true, type: "voice", duration: "0:14", read: true },
  { id: 5, mine: false, type: "text", text: "perfect, lmk when you're free to plan" },
];

function MessageBubble({ m }) {
  const base = "max-w-[72%] rounded-2xl px-3.5 py-2.5 text-[13.5px] font-medium";
  if (m.type === "text") {
    return (
      <div className={`flex flex-col ${m.mine ? "items-end" : "items-start"}`}>
        <div
          className={base}
          style={
            m.mine
              ? { background: ACCENT, color: "white", borderBottomRightRadius: 4 }
              : { background: "rgba(255,255,255,0.08)", color: "white", borderBottomLeftRadius: 4 }
          }
        >
          {m.text}
        </div>
        {m.mine && m.read && (
          <span className="flex items-center gap-1 mt-1 mr-1 text-[10px] text-white/35">
            <CheckCheck size={11} className="text-[#7C5CFC]" /> Read
          </span>
        )}
      </div>
    );
  }
  if (m.type === "image") {
    return (
      <div className={`flex flex-col ${m.mine ? "items-end" : "items-start"}`}>
        <div className="w-40 h-52 rounded-2xl overflow-hidden" style={{ background: "linear-gradient(160deg,#0F2027,#2C5364)" }} />
        {m.caption && <p className="text-[11px] text-white/40 mt-1">{m.caption}</p>}
      </div>
    );
  }
  if (m.type === "voice") {
    return (
      <div className={`flex ${m.mine ? "justify-end" : "justify-start"}`}>
        <div
          className="flex items-center gap-2.5 rounded-2xl px-3.5 py-2.5"
          style={m.mine ? { background: ACCENT } : { background: "rgba(255,255,255,0.08)" }}
        >
          <button className="w-7 h-7 rounded-full bg-white/25 flex items-center justify-center shrink-0">
            <Play size={11} className="text-white" fill="white" />
          </button>
          <div className="flex items-center gap-[2px]">
            {[3, 6, 9, 5, 12, 7, 4, 10, 6, 3].map((h, i) => (
              <span key={i} className="w-[2.5px] bg-white/70 rounded-full" style={{ height: h }} />
            ))}
          </div>
          <span className="text-[11px] text-white/85 font-semibold">{m.duration}</span>
        </div>
      </div>
    );
  }
  return null;
}

function ChatThread({ chat, onBack, onModerate }) {
  const [typingDots, setTypingDots] = useState(".");
  useEffect(() => {
    if (!chat.typing) return;
    const id = setInterval(() => setTypingDots((d) => (d.length >= 3 ? "." : d + ".")), 450);
    return () => clearInterval(id);
  }, [chat.typing]);

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex items-center gap-2.5 px-4 pt-4 pb-3 border-b border-white/10">
        <button onClick={onBack}>
          <ChevronLeft size={22} className="text-white" />
        </button>
        <div className="relative">
          <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-white text-[13px]" style={{ background: chat.group ? "linear-gradient(160deg,#7C5CFC,#3A1C71)" : ACCENT }}>
            {chat.group ? <UsersIcon size={15} /> : chat.name[0].toUpperCase()}
          </div>
          {!chat.group && chat.online && (
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-[#3ED598] border-2 border-[#0A0A0F]" />
          )}
        </div>
        <div className="flex-1">
          <p className="text-[13.5px] font-bold text-white">{chat.name}</p>
          <p className="text-[11px] text-white/40 font-medium">
            {chat.group ? `${chat.members.length} members` : chat.online ? "Online" : "Offline"}
          </p>
        </div>
        <button onClick={() => onModerate(chat.name)}>
          <MoreHorizontal size={19} className="text-white/60" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3">
        {THREAD.map((m) => (
          <MessageBubble key={m.id} m={m} />
        ))}
        {chat.typing && (
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full" style={{ background: ACCENT }} />
            <span className="bg-white/10 rounded-2xl px-3 py-2 text-[13px] text-white/60 font-medium">
              typing{typingDots}
            </span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 px-4 py-3 border-t border-white/10">
        <button><ImageIcon size={19} className="text-white/50" /></button>
        <input
          placeholder="Message…"
          className="flex-1 bg-white/[0.06] border border-white/10 rounded-full px-3.5 py-2 text-[13px] text-white outline-none placeholder-white/35"
        />
        <button><Mic size={19} className="text-white/50" /></button>
        <button style={{ background: ACCENT }} className="w-8 h-8 rounded-full flex items-center justify-center">
          <Send size={13} className="text-white" />
        </button>
      </div>
    </div>
  );
}

function InboxSection() {
  const [active, setActive] = useState(null);
  const [reportTarget, setReportTarget] = useState(null);
  return (
    <div className="w-full h-full">
      {!active ? (
        <div className="px-4 pt-5">
          <h1 className="text-[17px] font-black text-white mb-3">Inbox</h1>
          <div className="flex flex-col divide-y divide-white/5">
            {CHATS.map((c) => (
              <ChatListRow key={c.id} chat={c} onOpen={setActive} />
            ))}
          </div>
        </div>
      ) : (
        <ChatThread chat={active} onBack={() => setActive(null)} onModerate={setReportTarget} />
      )}
      <ModerationSheet target={reportTarget} onClose={() => setReportTarget(null)} />
    </div>
  );
}

// --- Activity / notifications --------------------------------------------------
const FOLLOW_REQUESTS = [
  { user: "priya.codes", mutual: "3 mutual followers" },
  { user: "leo.films", mutual: "12 mutual followers" },
];

const ACTIVITY = [
  { id: 1, type: "like", user: "kesh.travels", detail: "liked your video", time: "5m", icon: Heart, color: "#FF4D6D" },
  { id: 2, type: "comment", user: "noor.bakes", detail: "commented: \"this is so good\"", time: "22m", icon: MessageCircle, color: "#7C5CFC" },
  { id: 3, type: "mention", user: "sam.codes", detail: "mentioned you in a comment", time: "1h", icon: AtSign, color: "#3ED598" },
  { id: 4, type: "repost", user: "the.archive.fits", detail: "reposted your video", time: "3h", icon: Repeat2, color: "#FFB020" },
  { id: 5, type: "follow", user: "mira.codes", detail: "started following you", time: "1d", icon: UserPlus, color: "#7C5CFC" },
];

function ActivitySection() {
  const [requests, setRequests] = useState(FOLLOW_REQUESTS);

  const respond = (user) => setRequests((r) => r.filter((x) => x.user !== user));

  return (
    <div className="w-full h-full overflow-y-auto pb-10 px-4 pt-5">
      <div className="flex items-center gap-2 mb-4">
        <Bell size={17} className="text-white" />
        <h1 className="text-[17px] font-black text-white">Activity</h1>
      </div>

      {requests.length > 0 && (
        <div className="mb-6">
          <p className="text-[12.5px] font-bold text-white/45 mb-2.5">Follow requests</p>
          {requests.map((r) => (
            <div key={r.user} className="flex items-center gap-3 py-2">
              <div className="w-11 h-11 rounded-full flex items-center justify-center font-bold text-white text-[15px]" style={{ background: ACCENT }}>
                {r.user[0].toUpperCase()}
              </div>
              <div className="flex-1">
                <p className="text-[13.5px] font-bold text-white">@{r.user}</p>
                <p className="text-[11.5px] text-white/40">{r.mutual}</p>
              </div>
              <button onClick={() => respond(r.user)} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: ACCENT }}>
                <Check size={15} className="text-white" />
              </button>
              <button onClick={() => respond(r.user)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                <X size={15} className="text-white/70" />
              </button>
            </div>
          ))}
        </div>
      )}

      <p className="text-[12.5px] font-bold text-white/45 mb-2.5">This week</p>
      <div className="flex flex-col divide-y divide-white/5">
        {ACTIVITY.map((a) => (
          <div key={a.id} className="flex items-center gap-3 py-3">
            <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0" style={{ background: `${a.color}22` }}>
              <a.icon size={16} style={{ color: a.color }} fill={a.type === "like" ? a.color : "none"} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] text-white font-medium leading-snug">
                <span className="font-bold">@{a.user}</span> {a.detail}
              </p>
              <p className="text-[11px] text-white/35 mt-0.5">{a.time}</p>
            </div>
            <div className="w-8 h-11 rounded-md shrink-0" style={{ background: "linear-gradient(160deg,#3A1C71,#7C5CFC)" }} />
          </div>
        ))}
      </div>
    </div>
  );
}

// --- shell -----------------------------------------------------------------------
export default function TryTokSocialInbox() {
  const [view, setView] = useState("comments");
  const tabs = [
    { key: "comments", label: "Comments" },
    { key: "inbox", label: "Inbox" },
    { key: "activity", label: "Activity" },
  ];
  return (
    <div
      className="relative w-full mx-auto overflow-hidden"
      style={{
        maxWidth: 420,
        height: "100vh",
        background: "#0A0A0F",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, system-ui, sans-serif",
      }}
    >
      <div className="absolute top-0 left-0 right-0 z-10 flex justify-center gap-2 pt-3 pb-2 bg-[#0A0A0F]/90 backdrop-blur border-b border-white/5">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setView(t.key)}
            className="px-4 py-1.5 rounded-full text-[12px] font-bold transition"
            style={view === t.key ? { background: ACCENT, color: "white" } : { background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.4)" }}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="pt-12 h-full">
        {view === "comments" && <CommentsPanel />}
        {view === "inbox" && <InboxSection />}
        {view === "activity" && <ActivitySection />}
      </div>
    </div>
  );
}
