import React, { useState, useMemo, useRef } from "react";
import {
  UploadCloud, Image as ImageIcon, Music2, Globe2, Users, Lock,
  CalendarClock, Hash, AtSign, Search, TrendingUp, Flame, Video,
  X, Check, ChevronDown, Sparkles,
} from "lucide-react";

// ---------------------------------------------------------------------------
// TryTok — Upload + Discover / Trending
// Same system: bg #0A0A0F / coral #FF4D6D / violet #7C5CFC
// Signature: caption field parses #tags and @mentions live into chips —
// creation and discovery share one visual language (the tag).
// ---------------------------------------------------------------------------

const ACCENT = "linear-gradient(90deg,#FF4D6D,#7C5CFC)";

function extractTokens(text) {
  const tags = [...text.matchAll(/#[a-zA-Z0-9_]+/g)].map((m) => m[0]);
  const mentions = [...text.matchAll(/@[a-zA-Z0-9_.]+/g)].map((m) => m[0]);
  return { tags, mentions };
}

const SOUNDS = [
  { name: "original sound — you", uses: "New" },
  { name: "Golden Hour — slowed", uses: "412K videos" },
  { name: "Sped Up — club remix", uses: "1.1M videos" },
  { name: "lofi study beat", uses: "88K videos" },
  { name: "cinematic riser", uses: "204K videos" },
];

const PRIVACY = [
  { key: "public", label: "Public", desc: "Anyone on TryTok", icon: Globe2 },
  { key: "friends", label: "Friends", desc: "People you follow each other", icon: Users },
  { key: "private", label: "Private", desc: "Only you", icon: Lock },
];

// --- Upload page --------------------------------------------------------------
function UploadPage() {
  const [file, setFile] = useState(null);
  const [caption, setCaption] = useState("");
  const [sound, setSound] = useState(null);
  const [soundOpen, setSoundOpen] = useState(false);
  const [privacy, setPrivacy] = useState("public");
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [thumbIdx, setThumbIdx] = useState(0);
  const [scheduled, setScheduled] = useState(false);
  const [when, setWhen] = useState("");
  const inputRef = useRef(null);

  const { tags, mentions } = useMemo(() => extractTokens(caption), [caption]);
  const thumbs = [
    "linear-gradient(160deg,#3A1C71,#7C5CFC)",
    "linear-gradient(160deg,#0F2027,#2C5364)",
    "linear-gradient(160deg,#654321,#FF4D6D)",
    "linear-gradient(160deg,#1A1A2E,#7C5CFC)",
  ];

  return (
    <div className="w-full h-full overflow-y-auto pb-10">
      <div className="px-4 pt-5 pb-3">
        <h1 className="text-[17px] font-black text-white">New post</h1>
      </div>

      {/* file select */}
      {!file ? (
        <button
          onClick={() => setFile(thumbs[0])}
          className="mx-4 flex flex-col items-center justify-center gap-2.5 border-2 border-dashed border-white/15 rounded-2xl py-14 active:scale-[0.99] transition"
        >
          <div className="w-12 h-12 rounded-full bg-white/[0.06] flex items-center justify-center">
            <UploadCloud size={22} className="text-white/60" />
          </div>
          <span className="text-[13.5px] font-bold text-white">Select video to upload</span>
          <span className="text-[11.5px] text-white/35 font-medium">MP4 or WebM · up to 10 min</span>
        </button>
      ) : (
        <div className="px-4 flex gap-3">
          <div
            className="w-28 h-44 rounded-xl shrink-0 relative overflow-hidden"
            style={{ background: file }}
          >
            <button
              onClick={() => setFile(null)}
              className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-black/60 flex items-center justify-center"
            >
              <X size={12} className="text-white" />
            </button>
          </div>

          <div className="flex-1 flex flex-col gap-3">
            <textarea
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Describe your video… use # and @ to tag"
              rows={4}
              className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-3 py-2.5 text-white text-[13.5px] font-medium outline-none focus:border-[#7C5CFC]/70 resize-none placeholder-white/30"
            />
            {(tags.length > 0 || mentions.length > 0) && (
              <div className="flex flex-wrap gap-1.5">
                {tags.map((t) => (
                  <span key={t} className="flex items-center gap-1 text-[11px] font-bold px-2 py-1 rounded-full bg-[#FF4D6D]/15 text-[#FF4D6D]">
                    <Hash size={10} />{t.slice(1)}
                  </span>
                ))}
                {mentions.map((m) => (
                  <span key={m} className="flex items-center gap-1 text-[11px] font-bold px-2 py-1 rounded-full bg-[#7C5CFC]/15 text-[#7C5CFC]">
                    <AtSign size={10} />{m.slice(1)}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {file && (
        <div className="px-4 mt-6 flex flex-col gap-2.5">
          {/* sound */}
          <button
            onClick={() => setSoundOpen(true)}
            className="flex items-center justify-between bg-white/[0.05] rounded-xl px-3.5 py-3"
          >
            <div className="flex items-center gap-2.5">
              <Music2 size={16} className="text-white/60" />
              <span className="text-[13px] font-semibold text-white/90 truncate max-w-[180px]">
                {sound ? sound.name : "Add sound"}
              </span>
            </div>
            <ChevronDown size={15} className="text-white/40" />
          </button>

          {/* thumbnail */}
          <div className="bg-white/[0.05] rounded-xl px-3.5 py-3">
            <div className="flex items-center gap-2.5 mb-2.5">
              <ImageIcon size={16} className="text-white/60" />
              <span className="text-[13px] font-semibold text-white/90">Choose thumbnail</span>
            </div>
            <div className="flex gap-2">
              {thumbs.map((g, i) => (
                <button
                  key={i}
                  onClick={() => setThumbIdx(i)}
                  className="w-12 h-16 rounded-lg shrink-0 relative"
                  style={{
                    background: g,
                    outline: thumbIdx === i ? "2px solid #FF4D6D" : "2px solid transparent",
                    outlineOffset: 2,
                  }}
                >
                  {thumbIdx === i && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#FF4D6D] flex items-center justify-center">
                      <Check size={10} className="text-white" />
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* privacy */}
          <button
            onClick={() => setPrivacyOpen(true)}
            className="flex items-center justify-between bg-white/[0.05] rounded-xl px-3.5 py-3"
          >
            <div className="flex items-center gap-2.5">
              {React.createElement(PRIVACY.find((p) => p.key === privacy).icon, {
                size: 16,
                className: "text-white/60",
              })}
              <span className="text-[13px] font-semibold text-white/90">
                {PRIVACY.find((p) => p.key === privacy).label}
              </span>
            </div>
            <ChevronDown size={15} className="text-white/40" />
          </button>

          {/* schedule */}
          <div className="bg-white/[0.05] rounded-xl px-3.5 py-3">
            <button
              onClick={() => setScheduled((s) => !s)}
              className="flex items-center justify-between w-full"
            >
              <div className="flex items-center gap-2.5">
                <CalendarClock size={16} className="text-white/60" />
                <span className="text-[13px] font-semibold text-white/90">Schedule for later</span>
              </div>
              <span
                className="w-9 h-5 rounded-full relative transition-colors"
                style={{ background: scheduled ? "#FF4D6D" : "rgba(255,255,255,0.15)" }}
              >
                <span
                  className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all"
                  style={{ left: scheduled ? 18 : 2 }}
                />
              </span>
            </button>
            {scheduled && (
              <input
                type="datetime-local"
                value={when}
                onChange={(e) => setWhen(e.target.value)}
                className="w-full mt-3 bg-white/[0.06] border border-white/10 rounded-lg px-3 py-2 text-[12.5px] text-white outline-none"
              />
            )}
          </div>
        </div>
      )}

      {file && (
        <div className="px-4 mt-6">
          <button
            className="w-full py-3.5 rounded-xl font-bold text-[14.5px] text-white active:scale-[0.98] transition"
            style={{ background: ACCENT }}
          >
            {scheduled ? "Schedule post" : "Post"}
          </button>
        </div>
      )}

      {/* sound sheet */}
      {soundOpen && (
        <div className="fixed inset-0 z-30 flex items-end" style={{ maxWidth: 420, margin: "0 auto" }}>
          <div className="absolute inset-0 bg-black/60" onClick={() => setSoundOpen(false)} />
          <div className="relative w-full bg-[#131318] rounded-t-2xl px-4 pt-4 pb-6 max-h-[70%] overflow-y-auto">
            <div className="w-9 h-1 bg-white/20 rounded-full mx-auto mb-4" />
            <h3 className="text-[14.5px] font-black text-white mb-3">Add sound</h3>
            {SOUNDS.map((s) => (
              <button
                key={s.name}
                onClick={() => {
                  setSound(s);
                  setSoundOpen(false);
                }}
                className="flex items-center gap-3 w-full py-2.5 border-b border-white/5 last:border-0"
              >
                <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: ACCENT }}>
                  <Music2 size={14} className="text-white" />
                </div>
                <div className="text-left">
                  <p className="text-[13px] font-semibold text-white">{s.name}</p>
                  <p className="text-[11px] text-white/40">{s.uses}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* privacy sheet */}
      {privacyOpen && (
        <div className="fixed inset-0 z-30 flex items-end" style={{ maxWidth: 420, margin: "0 auto" }}>
          <div className="absolute inset-0 bg-black/60" onClick={() => setPrivacyOpen(false)} />
          <div className="relative w-full bg-[#131318] rounded-t-2xl px-4 pt-4 pb-6">
            <div className="w-9 h-1 bg-white/20 rounded-full mx-auto mb-4" />
            <h3 className="text-[14.5px] font-black text-white mb-3">Who can view this post</h3>
            {PRIVACY.map((p) => (
              <button
                key={p.key}
                onClick={() => {
                  setPrivacy(p.key);
                  setPrivacyOpen(false);
                }}
                className="flex items-center gap-3 w-full py-2.5"
              >
                <p.icon size={17} className="text-white/70" />
                <div className="text-left flex-1">
                  <p className="text-[13px] font-semibold text-white">{p.label}</p>
                  <p className="text-[11px] text-white/40">{p.desc}</p>
                </div>
                {privacy === p.key && <Check size={16} className="text-[#FF4D6D]" />}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// --- Discover / Trending page ---------------------------------------------------
const RESULT_TABS = ["Top", "Users", "Hashtags", "Sounds", "Videos"];

const TRENDING_TAGS = [
  { tag: "#buildinpublic", views: "482.1M" },
  { tag: "#glowup", views: "1.2B" },
  { tag: "#cookingtok", views: "340.5M" },
  { tag: "#studywithme", views: "220.9M" },
  { tag: "#pettok", views: "3.4B" },
  { tag: "#thrift", views: "180.2M" },
];

const TRENDING_SOUNDS = [
  { name: "Golden Hour — slowed", artist: "JVKE", uses: "412K" },
  { name: "Sped Up — club remix", artist: "unknown", uses: "1.1M" },
  { name: "cinematic riser", artist: "SFX Lab", uses: "204K" },
];

const SUGGESTED_USERS = [
  { user: "kesh.travels", followers: "88.2K", verified: false },
  { user: "noor.bakes", followers: "412K", verified: true },
  { user: "the.archive.fits", followers: "56.7K", verified: false },
];

const TRENDING_VIDEOS = [
  "linear-gradient(160deg,#3A1C71,#7C5CFC)",
  "linear-gradient(160deg,#0F2027,#2C5364)",
  "linear-gradient(160deg,#654321,#FF4D6D)",
  "linear-gradient(160deg,#1A1A2E,#7C5CFC)",
  "linear-gradient(160deg,#2C0735,#FF4D6D)",
  "linear-gradient(160deg,#043927,#3ED598)",
];

function DiscoverPage() {
  const [query, setQuery] = useState("");
  const [resultTab, setResultTab] = useState("Top");
  const searching = query.trim().length > 0;

  return (
    <div className="w-full h-full overflow-y-auto pb-10">
      <div className="px-4 pt-5 pb-3">
        <div className="flex items-center gap-2.5 bg-white/[0.06] border border-white/10 rounded-full px-4 py-2.5">
          <Search size={16} className="text-white/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search users, hashtags, sounds, videos"
            className="bg-transparent outline-none text-[13.5px] text-white placeholder-white/35 w-full font-medium"
          />
          {query && (
            <button onClick={() => setQuery("")}>
              <X size={14} className="text-white/40" />
            </button>
          )}
        </div>
      </div>

      {searching ? (
        <>
          <div className="flex gap-4 px-4 border-b border-white/10 overflow-x-auto">
            {RESULT_TABS.map((t) => (
              <button
                key={t}
                onClick={() => setResultTab(t)}
                className={`relative pb-2.5 text-[13px] font-bold whitespace-nowrap ${
                  resultTab === t ? "text-white" : "text-white/40"
                }`}
              >
                {t}
                {resultTab === t && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2.5px] rounded-full" style={{ background: ACCENT }} />
                )}
              </button>
            ))}
          </div>
          <div className="px-4 py-4 flex flex-col gap-3">
            {(resultTab === "Top" || resultTab === "Users") &&
              SUGGESTED_USERS.filter((u) => u.user.includes(query.toLowerCase())).map((u) => (
                <div key={u.user} className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full flex items-center justify-center font-bold text-white text-[14px]" style={{ background: ACCENT }}>
                    {u.user[0].toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <p className="text-[13.5px] font-bold text-white">@{u.user}</p>
                    <p className="text-[11.5px] text-white/40">{u.followers} followers</p>
                  </div>
                  <button className="text-[12px] font-bold border border-white/20 rounded-full px-3 py-1.5 text-white">
                    Follow
                  </button>
                </div>
              ))}
            {(resultTab === "Top" || resultTab === "Hashtags") &&
              TRENDING_TAGS.filter((t) => t.tag.includes(query.toLowerCase())).map((t) => (
                <div key={t.tag} className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-white/[0.06] flex items-center justify-center">
                    <Hash size={16} className="text-[#FF4D6D]" />
                  </div>
                  <div>
                    <p className="text-[13.5px] font-bold text-white">{t.tag}</p>
                    <p className="text-[11.5px] text-white/40">{t.views} views</p>
                  </div>
                </div>
              ))}
            {resultTab === "Videos" && (
              <div className="grid grid-cols-3 gap-[2px] -mx-4">
                {TRENDING_VIDEOS.map((g, i) => (
                  <div key={i} className="aspect-[9/13]" style={{ background: g }} />
                ))}
              </div>
            )}
            {resultTab === "Sounds" &&
              TRENDING_SOUNDS.map((s) => (
                <div key={s.name} className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-lg flex items-center justify-center" style={{ background: ACCENT }}>
                    <Music2 size={16} className="text-white" />
                  </div>
                  <div>
                    <p className="text-[13.5px] font-bold text-white">{s.name}</p>
                    <p className="text-[11.5px] text-white/40">{s.artist} · {s.uses} videos</p>
                  </div>
                </div>
              ))}
          </div>
        </>
      ) : (
        <>
          {/* trending hashtags */}
          <div className="px-4 mt-1">
            <div className="flex items-center gap-1.5 mb-2.5">
              <Flame size={15} className="text-[#FF4D6D]" />
              <h2 className="text-[14px] font-black text-white">Trending hashtags</h2>
            </div>
            <div className="flex flex-col gap-2.5">
              {TRENDING_TAGS.map((t, i) => (
                <div key={t.tag} className="flex items-center gap-3">
                  <span className="w-5 text-[13px] font-black text-white/30">{i + 1}</span>
                  <div className="flex-1">
                    <p className="text-[13.5px] font-bold text-white">{t.tag}</p>
                    <p className="text-[11px] text-white/40">{t.views} views</p>
                  </div>
                  <TrendingUp size={14} className="text-[#3ED598]" />
                </div>
              ))}
            </div>
          </div>

          {/* trending sounds */}
          <div className="px-4 mt-6">
            <div className="flex items-center gap-1.5 mb-2.5">
              <Sparkles size={15} className="text-[#7C5CFC]" />
              <h2 className="text-[14px] font-black text-white">Trending sounds</h2>
            </div>
            <div className="flex flex-col gap-2.5">
              {TRENDING_SOUNDS.map((s) => (
                <div key={s.name} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: ACCENT }}>
                    <Music2 size={14} className="text-white" />
                  </div>
                  <div>
                    <p className="text-[13px] font-bold text-white">{s.name}</p>
                    <p className="text-[11px] text-white/40">{s.artist} · {s.uses} videos</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* suggested users */}
          <div className="px-4 mt-6">
            <div className="flex items-center gap-1.5 mb-2.5">
              <Users size={15} className="text-white/70" />
              <h2 className="text-[14px] font-black text-white">Accounts to follow</h2>
            </div>
            <div className="flex gap-3 overflow-x-auto pb-1">
              {SUGGESTED_USERS.map((u) => (
                <div key={u.user} className="flex flex-col items-center gap-1.5 shrink-0 w-20">
                  <div className="w-14 h-14 rounded-full flex items-center justify-center font-bold text-white text-[16px]" style={{ background: ACCENT }}>
                    {u.user[0].toUpperCase()}
                  </div>
                  <p className="text-[11px] font-bold text-white truncate w-full text-center">@{u.user}</p>
                  <button className="text-[10.5px] font-bold bg-white/10 text-white rounded-full px-2.5 py-1 w-full">
                    Follow
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* trending videos grid */}
          <div className="mt-6">
            <div className="flex items-center gap-1.5 mb-2.5 px-4">
              <Video size={15} className="text-white/70" />
              <h2 className="text-[14px] font-black text-white">Trending videos</h2>
            </div>
            <div className="grid grid-cols-3 gap-[2px]">
              {TRENDING_VIDEOS.map((g, i) => (
                <div key={i} className="aspect-[9/13]" style={{ background: g }} />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// --- shell ------------------------------------------------------------------------
export default function TryTokCreateExplore() {
  const [view, setView] = useState("upload");
  return (
    <div
      className="relative w-full mx-auto overflow-hidden"
      style={{
        maxWidth: 420,
        height: "100vh",
        background: "#0A0A0F",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, system-ui, sans-serif",
      }}
    >
      <div className="absolute top-0 left-0 right-0 z-10 flex justify-center gap-2 pt-3 pb-2 bg-[#0A0A0F]/90 backdrop-blur border-b border-white/5">
        {["upload", "discover"].map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`px-4 py-1.5 rounded-full text-[12px] font-bold capitalize transition ${
              view === v ? "text-white" : "text-white/40"
            }`}
            style={view === v ? { background: ACCENT } : { background: "rgba(255,255,255,0.06)" }}
          >
            {v}
          </button>
        ))}
      </div>
      <div className="pt-12 h-full">
        {view === "upload" ? <UploadPage /> : <DiscoverPage />}
      </div>
    </div>
  );
}
