import React, { useState } from "react";
import {
  LayoutDashboard, Users, Video, Flag, Copyright, Radio, Banknote,
  Sparkles, Search, Ban, EyeOff, Trash2, ShieldCheck, Star, CheckCircle2,
  XCircle, ChevronDown, AlertTriangle, Gift, Coins,
} from "lucide-react";

// ---------------------------------------------------------------------------
// TryTok — Admin Panel + Recommendation Algorithm layout
// Same system: bg #0A0A0F / coral #FF4D6D / violet #7C5CFC
// Signature: every moderation action shows its consequence inline (status
// badge flips immediately) rather than behind a confirm-and-refresh step —
// admin work is a control surface, not a form.
// ---------------------------------------------------------------------------

const ACCENT = "linear-gradient(90deg,#FF4D6D,#7C5CFC)";

const STATUS_COLORS = {
  active: "#3ED598",
  suspended: "#FFB020",
  banned: "#FF4D6D",
  shadowbanned: "#7C5CFC",
  pending: "#FFB020",
};

function StatusBadge({ status }) {
  return (
    <span
      className="text-[10px] font-bold px-2 py-0.5 rounded-full capitalize"
      style={{ background: `${STATUS_COLORS[status]}22`, color: STATUS_COLORS[status] }}
    >
      {status}
    </span>
  );
}

// --- Overview ------------------------------------------------------------------
const STATS = [
  { label: "Total users", value: "2.84M", delta: "+1.2%" },
  { label: "DAU", value: "412K", delta: "+3.4%" },
  { label: "Videos today", value: "88.1K", delta: "+0.8%" },
  { label: "Pending reports", value: "312", delta: "-6.1%" },
  { label: "Live now", value: "1,204", delta: "+9.0%" },
  { label: "Revenue (24h)", value: "$182K", delta: "+2.2%" },
];

function OverviewSection() {
  return (
    <div className="px-4 pt-4 pb-8">
      <div className="grid grid-cols-2 gap-3">
        {STATS.map((s) => (
          <div key={s.label} className="bg-white/[0.05] rounded-xl p-3.5">
            <p className="text-[11px] text-white/45 font-semibold">{s.label}</p>
            <p className="text-[18px] font-black text-white mt-1">{s.value}</p>
            <p className={`text-[10.5px] font-bold mt-0.5 ${s.delta.startsWith("+") ? "text-[#3ED598]" : "text-[#FF4D6D]"}`}>
              {s.delta} vs yesterday
            </p>
          </div>
        ))}
      </div>
      <div className="mt-5 bg-white/[0.05] rounded-xl p-4">
        <p className="text-[12.5px] font-bold text-white/60 mb-3">Platform activity — 7 days</p>
        <div className="flex items-end gap-2 h-20">
          {[55, 62, 48, 70, 66, 90, 80].map((h, i) => (
            <div key={i} className="flex-1 rounded-t-md" style={{ height: `${h}%`, background: ACCENT }} />
          ))}
        </div>
      </div>
    </div>
  );
}

// --- Users management -----------------------------------------------------------
const USERS = [
  { id: 1, user: "mira.codes", status: "active", verified: true, creatorPending: false },
  { id: 2, user: "spam.acct42", status: "active", verified: false, creatorPending: false },
  { id: 3, user: "kesh.travels", status: "active", verified: false, creatorPending: true },
  { id: 4, user: "rulebreaker99", status: "suspended", verified: false, creatorPending: false },
  { id: 5, user: "botfarm_x", status: "shadowbanned", verified: false, creatorPending: false },
];

function UserRow({ u, onAction }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-white/5 py-2.5">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-white text-[13px]" style={{ background: ACCENT }}>
          {u.user[0].toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <p className="text-[13px] font-bold text-white truncate">@{u.user}</p>
            {u.verified && <ShieldCheck size={12} className="text-[#7C5CFC]" />}
          </div>
          <StatusBadge status={u.status} />
        </div>
        <button onClick={() => setOpen((o) => !o)} className="flex items-center gap-1 text-[11.5px] font-bold text-white/60">
          Actions <ChevronDown size={13} className={open ? "rotate-180 transition" : "transition"} />
        </button>
      </div>
      {open && (
        <div className="flex flex-wrap gap-2 mt-2.5 pl-12">
          {u.creatorPending && (
            <button onClick={() => onAction(u.id, "approve")} className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-[#3ED598]/15 text-[#3ED598]">
              <CheckCircle2 size={12} /> Approve creator
            </button>
          )}
          <button onClick={() => onAction(u.id, "suspended")} className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-[#FFB020]/15 text-[#FFB020]">
            <AlertTriangle size={12} /> Suspend
          </button>
          <button onClick={() => onAction(u.id, "shadowbanned")} className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-[#7C5CFC]/15 text-[#7C5CFC]">
            <EyeOff size={12} /> Shadow-ban
          </button>
          <button onClick={() => onAction(u.id, "banned")} className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-[#FF4D6D]/15 text-[#FF4D6D]">
            <Ban size={12} /> Ban
          </button>
          <button onClick={() => onAction(u.id, "delete")} className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-white/10 text-white/70">
            <Trash2 size={12} /> Delete
          </button>
        </div>
      )}
    </div>
  );
}

function UsersSection() {
  const [users, setUsers] = useState(USERS);
  const [query, setQuery] = useState("");

  const applyAction = (id, action) => {
    if (action === "delete") {
      setUsers((u) => u.filter((x) => x.id !== id));
      return;
    }
    setUsers((u) =>
      u.map((x) =>
        x.id === id
          ? action === "approve"
            ? { ...x, creatorPending: false, verified: true }
            : { ...x, status: action }
          : x
      )
    );
  };

  const filtered = users.filter((u) => u.user.includes(query.toLowerCase()));

  return (
    <div className="px-4 pt-4 pb-8">
      <div className="flex items-center gap-2 bg-white/[0.06] border border-white/10 rounded-full px-3.5 py-2 mb-3">
        <Search size={14} className="text-white/40" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search users…"
          className="bg-transparent outline-none text-[13px] text-white placeholder-white/35 w-full font-medium"
        />
      </div>
      {filtered.map((u) => (
        <UserRow key={u.id} u={u} onAction={applyAction} />
      ))}
    </div>
  );
}

// --- Content management -----------------------------------------------------------
const VIDEOS = [
  { id: 1, user: "mira.codes", caption: "rewriting my portfolio at 2am…", featured: true, gradient: "linear-gradient(160deg,#3A1C71,#7C5CFC)" },
  { id: 2, user: "kesh.travels", caption: "hidden waterfall, 40 min hike", featured: false, gradient: "linear-gradient(160deg,#0F2027,#2C5364)" },
  { id: 3, user: "noor.bakes", caption: "3-ingredient pistachio cookies", featured: false, gradient: "linear-gradient(160deg,#654321,#FF4D6D)" },
];

function ContentSection() {
  const [videos, setVideos] = useState(VIDEOS);
  const toggleFeature = (id) => setVideos((v) => v.map((x) => (x.id === id ? { ...x, featured: !x.featured } : x)));
  const remove = (id) => setVideos((v) => v.filter((x) => x.id !== id));

  return (
    <div className="px-4 pt-4 pb-8">
      {videos.map((v) => (
        <div key={v.id} className="flex items-center gap-3 border-b border-white/5 py-3">
          <div className="w-11 h-14 rounded-lg shrink-0" style={{ background: v.gradient }} />
          <div className="flex-1 min-w-0">
            <p className="text-[12.5px] font-bold text-white">@{v.user}</p>
            <p className="text-[12px] text-white/50 truncate">{v.caption}</p>
          </div>
          <button
            onClick={() => toggleFeature(v.id)}
            className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: v.featured ? `${"#FFD700"}22` : "rgba(255,255,255,0.08)" }}
          >
            <Star size={14} fill={v.featured ? "#FFD700" : "none"} className={v.featured ? "text-[#FFD700]" : "text-white/40"} />
          </button>
          <button onClick={() => remove(v.id)} className="w-8 h-8 rounded-full bg-white/[0.08] flex items-center justify-center">
            <Trash2 size={14} className="text-[#FF4D6D]" />
          </button>
        </div>
      ))}
    </div>
  );
}

// --- Reports + copyright ------------------------------------------------------------
const REPORTS = [
  { id: 1, kind: "user", target: "rulebreaker99", reason: "Harassment", reporter: "mira.codes" },
  { id: 2, kind: "video", target: "\"y2k thrift haul pt.4\"", reason: "Misleading content", reporter: "noor.bakes" },
  { id: 3, kind: "comment", target: "comment on @kesh.travels' video", reason: "Spam", reporter: "sam.codes" },
];

const COPYRIGHT = [
  { id: 1, video: "\"Sped Up — club remix\" sound", claimant: "Sony Music", status: "pending" },
  { id: 2, video: "\"Golden Hour — slowed\" sound", claimant: "Independent artist", status: "pending" },
];

function ReportsSection() {
  const [reports, setReports] = useState(REPORTS);
  const [claims, setClaims] = useState(COPYRIGHT);

  return (
    <div className="px-4 pt-4 pb-8">
      <div className="flex items-center gap-1.5 mb-2.5">
        <Flag size={14} className="text-[#FF4D6D]" />
        <h2 className="text-[13.5px] font-black text-white">User reports</h2>
      </div>
      {reports.map((r) => (
        <div key={r.id} className="border-b border-white/5 py-3">
          <p className="text-[12.5px] font-bold text-white capitalize">{r.kind} report — {r.target}</p>
          <p className="text-[11.5px] text-white/45 mt-0.5">Reason: {r.reason} · by @{r.reporter}</p>
          <div className="flex gap-2 mt-2">
            <button onClick={() => setReports((rs) => rs.filter((x) => x.id !== r.id))} className="text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-[#FF4D6D]/15 text-[#FF4D6D]">
              Take action
            </button>
            <button onClick={() => setReports((rs) => rs.filter((x) => x.id !== r.id))} className="text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-white/10 text-white/60">
              Dismiss
            </button>
          </div>
        </div>
      ))}

      <div className="flex items-center gap-1.5 mb-2.5 mt-5">
        <Copyright size={14} className="text-[#7C5CFC]" />
        <h2 className="text-[13.5px] font-black text-white">Copyright claims</h2>
      </div>
      {claims.map((c) => (
        <div key={c.id} className="flex items-center justify-between border-b border-white/5 py-3">
          <div>
            <p className="text-[12.5px] font-bold text-white">{c.video}</p>
            <p className="text-[11.5px] text-white/45 mt-0.5">Claimant: {c.claimant}</p>
          </div>
          <div className="flex gap-1.5">
            <button onClick={() => setClaims((cs) => cs.filter((x) => x.id !== c.id))} className="w-7 h-7 rounded-full bg-[#3ED598]/15 flex items-center justify-center">
              <CheckCircle2 size={13} className="text-[#3ED598]" />
            </button>
            <button onClick={() => setClaims((cs) => cs.filter((x) => x.id !== c.id))} className="w-7 h-7 rounded-full bg-[#FF4D6D]/15 flex items-center justify-center">
              <XCircle size={13} className="text-[#FF4D6D]" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

// --- Live + payouts ------------------------------------------------------------------
const LIVE_STREAMS = [
  { id: 1, user: "mira.codes", viewers: "1.2K", flagged: false },
  { id: 2, user: "unverified_777", viewers: "84", flagged: true },
];

const WITHDRAWALS = [
  { id: 1, user: "the.archive.fits", amount: "$412.00", method: "PayPal" },
  { id: 2, user: "noor.bakes", amount: "$1,204.50", method: "Stripe" },
];

function LiveSection() {
  const [streams, setStreams] = useState(LIVE_STREAMS);
  return (
    <div className="px-4 pt-4 pb-8">
      <div className="flex items-center gap-1.5 mb-2.5">
        <Radio size={14} className="text-[#FF4D6D]" />
        <h2 className="text-[13.5px] font-black text-white">Active live streams</h2>
      </div>
      {streams.map((s) => (
        <div key={s.id} className="flex items-center gap-3 border-b border-white/5 py-3">
          <span className="w-2 h-2 rounded-full bg-[#FF4D6D] animate-pulse" />
          <div className="flex-1">
            <p className="text-[12.5px] font-bold text-white">@{s.user} {s.flagged && <span className="text-[10px] font-bold text-[#FFB020] ml-1">flagged</span>}</p>
            <p className="text-[11.5px] text-white/45">{s.viewers} viewers</p>
          </div>
          <button onClick={() => setStreams((st) => st.filter((x) => x.id !== s.id))} className="text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-[#FF4D6D]/15 text-[#FF4D6D]">
            End stream
          </button>
        </div>
      ))}
    </div>
  );
}

function PayoutsSection() {
  const [reqs, setReqs] = useState(WITHDRAWALS);
  return (
    <div className="px-4 pt-4 pb-8">
      <div className="flex items-center gap-1.5 mb-2.5">
        <Banknote size={14} className="text-[#3ED598]" />
        <h2 className="text-[13.5px] font-black text-white">Withdrawal requests</h2>
      </div>
      {reqs.map((r) => (
        <div key={r.id} className="flex items-center justify-between border-b border-white/5 py-3">
          <div>
            <p className="text-[12.5px] font-bold text-white">@{r.user}</p>
            <p className="text-[11.5px] text-white/45">{r.amount} via {r.method}</p>
          </div>
          <div className="flex gap-1.5">
            <button onClick={() => setReqs((rs) => rs.filter((x) => x.id !== r.id))} className="text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-[#3ED598]/15 text-[#3ED598]">
              Approve
            </button>
            <button onClick={() => setReqs((rs) => rs.filter((x) => x.id !== r.id))} className="text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-[#FF4D6D]/15 text-[#FF4D6D]">
              Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

// --- Recommendation algorithm layout --------------------------------------------------
function AlgorithmSection() {
  const [weights, setWeights] = useState({ watchTime: 40, likes: 20, comments: 15, shares: 15, behavior: 10 });
  const update = (k, v) => setWeights((w) => ({ ...w, [k]: Number(v) }));
  const total = Object.values(weights).reduce((a, b) => a + b, 0);

  const SIGNALS = [
    { key: "watchTime", label: "Watch time / completion rate" },
    { key: "likes", label: "Likes" },
    { key: "comments", label: "Comments" },
    { key: "shares", label: "Shares & reposts" },
    { key: "behavior", label: "Follow graph & interest history" },
  ];

  return (
    <div className="px-4 pt-4 pb-8">
      <div className="flex items-center gap-1.5 mb-1">
        <Sparkles size={14} className="text-[#7C5CFC]" />
        <h2 className="text-[13.5px] font-black text-white">"For You" ranking model</h2>
      </div>
      <p className="text-[11.5px] text-white/45 font-medium mb-4">
        Each candidate video gets a relevance score = Σ (signal × weight). Weights are tunable per cohort.
      </p>

      {SIGNALS.map((s) => (
        <div key={s.key} className="mb-4">
          <div className="flex justify-between mb-1">
            <span className="text-[12.5px] font-semibold text-white">{s.label}</span>
            <span className="text-[12.5px] font-bold text-[#7C5CFC]">{weights[s.key]}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={weights[s.key]}
            onChange={(e) => update(s.key, e.target.value)}
            className="w-full accent-[#FF4D6D]"
          />
        </div>
      ))}
      <p className={`text-[11px] font-bold mb-5 ${total === 100 ? "text-[#3ED598]" : "text-[#FFB020]"}`}>
        Weights total: {total}% {total !== 100 && "(should sum to 100%)"}
      </p>

      <div className="bg-white/[0.05] rounded-xl p-4">
        <p className="text-[12.5px] font-bold text-white/70 mb-3">Sample score breakdown — video #48213</p>
        {SIGNALS.map((s) => {
          const raw = { watchTime: 0.82, likes: 0.64, comments: 0.41, shares: 0.55, behavior: 0.70 }[s.key];
          const contrib = ((weights[s.key] / 100) * raw * 100).toFixed(1);
          return (
            <div key={s.key} className="flex items-center justify-between text-[11.5px] py-1">
              <span className="text-white/60">{s.label}</span>
              <span className="text-white font-semibold">{raw.toFixed(2)} × {weights[s.key]}% = {contrib}</span>
            </div>
          );
        })}
        <div className="border-t border-white/10 mt-2 pt-2 flex justify-between">
          <span className="text-[12px] font-bold text-white">Final relevance score</span>
          <span className="text-[12px] font-black text-[#FF4D6D]">
            {SIGNALS.reduce((acc, s) => {
              const raw = { watchTime: 0.82, likes: 0.64, comments: 0.41, shares: 0.55, behavior: 0.70 }[s.key];
              return acc + (weights[s.key] / 100) * raw * 100;
            }, 0).toFixed(1)}
          </span>
        </div>
      </div>
    </div>
  );
}

// --- shell ------------------------------------------------------------------------
const SECTIONS = [
  { key: "overview", label: "Overview", icon: LayoutDashboard, comp: OverviewSection },
  { key: "users", label: "Users", icon: Users, comp: UsersSection },
  { key: "content", label: "Content", icon: Video, comp: ContentSection },
  { key: "reports", label: "Reports", icon: Flag, comp: ReportsSection },
  { key: "live", label: "Live", icon: Radio, comp: LiveSection },
  { key: "payouts", label: "Payouts", icon: Banknote, comp: PayoutsSection },
  { key: "algorithm", label: "Algorithm", icon: Sparkles, comp: AlgorithmSection },
];

export default function TryTokAdminPanel() {
  const [active, setActive] = useState("overview");
  const Active = SECTIONS.find((s) => s.key === active).comp;

  return (
    <div
      className="relative w-full mx-auto overflow-hidden flex flex-col"
      style={{
        maxWidth: 420,
        height: "100vh",
        background: "#0A0A0F",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, system-ui, sans-serif",
      }}
    >
      <div className="px-4 pt-5 pb-3 border-b border-white/5">
        <h1 className="text-[16px] font-black text-white">TryTok Admin</h1>
        <p className="text-[11.5px] text-white/40 font-medium">Platform control panel</p>
      </div>

      <div className="flex gap-1.5 px-3 py-2.5 overflow-x-auto border-b border-white/5">
        {SECTIONS.map((s) => (
          <button
            key={s.key}
            onClick={() => setActive(s.key)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11.5px] font-bold whitespace-nowrap transition"
            style={active === s.key ? { background: ACCENT, color: "white" } : { background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.45)" }}
          >
            <s.icon size={12} />
            {s.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto">
        <Active />
      </div>
    </div>
  );
}
