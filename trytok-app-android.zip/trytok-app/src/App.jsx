import React from "react";
import { Routes, Route, Link, useLocation } from "react-router-dom";

import Feed from "./pages/Feed.jsx";
import AuthProfile from "./pages/AuthProfile.jsx";
import CreateExplore from "./pages/CreateExplore.jsx";
import SocialInbox from "./pages/SocialInbox.jsx";
import LiveMonetization from "./pages/LiveMonetization.jsx";
import AdminPanel from "./pages/AdminPanel.jsx";

const ROUTES = [
  { path: "/", label: "Feed", element: <Feed /> },
  { path: "/auth", label: "Auth / Profile", element: <AuthProfile /> },
  { path: "/create", label: "Upload / Discover", element: <CreateExplore /> },
  { path: "/social", label: "Social / Inbox", element: <SocialInbox /> },
  { path: "/live", label: "Live / Wallet", element: <LiveMonetization /> },
  { path: "/admin", label: "Admin Panel", element: <AdminPanel /> },
];

// Lightweight dev switcher so every phase is reachable in one running app.
// Each page below is a self-contained full-screen "phone" component;
// in production this bar would be removed and phases would be wired
// together as real in-app navigation (bottom tab bar, etc.).
function DevSwitcher() {
  const location = useLocation();
  return (
    <div className="fixed top-0 left-0 right-0 z-50 flex gap-1.5 overflow-x-auto bg-black/80 backdrop-blur px-2 py-1.5 border-b border-white/10">
      {ROUTES.map((r) => (
        <Link
          key={r.path}
          to={r.path}
          className="whitespace-nowrap text-[11px] font-bold px-2.5 py-1 rounded-full"
          style={{
            background: location.pathname === r.path ? "linear-gradient(90deg,#FF4D6D,#7C5CFC)" : "rgba(255,255,255,0.08)",
            color: location.pathname === r.path ? "white" : "rgba(255,255,255,0.5)",
          }}
        >
          {r.label}
        </Link>
      ))}
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-[#0A0A0F] flex flex-col items-center">
      <DevSwitcher />
      <div className="pt-8 w-full flex justify-center">
        <Routes>
          {ROUTES.map((r) => (
            <Route key={r.path} path={r.path} element={r.element} />
          ))}
        </Routes>
      </div>
    </div>
  );
}
