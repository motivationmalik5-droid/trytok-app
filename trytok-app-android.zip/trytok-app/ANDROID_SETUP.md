# Building the TryTok Android App (APK)

## What's in this zip

- Full Vite/React project (unchanged) + Capacitor wiring:
  - `capacitor.config.ts` — app ID `com.trytok.app`, splash/status bar config
  - `package.json` — Capacitor deps + `cap:sync`, `android:open`, `android:build` scripts
  - `android/` — a hand-prepared Capacitor 6 Android project skeleton: manifest, `MainActivity.java`, Gradle build files, brand colors/styles, FileProvider config

## Important: one file I genuinely cannot generate here

This was built in a sandbox with **no internet access** (confirmed: requests to `services.gradle.org` are blocked, and no local Gradle install exists to copy the jar from). Concretely:

- ✅ `android/gradlew` and `android/gradlew.bat` — included, full standard Gradle wrapper launcher scripts (plain text, so these could be hand-written correctly).
- ❌ `android/gradle/wrapper/gradle-wrapper.jar` — **not included**. This is a compiled binary, not source — there's no way to hand-author it correctly, and it must come from Gradle's servers or a local Gradle install.
- ❌ npm packages (`@capacitor/core`, `@capacitor/android`, etc.) — listed in `package.json` but not installed.

I actually ran `./gradlew assembleDebug` here to confirm — it fails with:
```
Error: Could not find or load main class org.gradle.wrapper.GradleWrapperMain
```
That's expected and will disappear the moment the jar exists (step 1 below on your machine).

## Prerequisites (on your machine)

- Node.js 18+
- JDK 17
- Android Studio (includes the Android SDK) — easiest way to get `gradle` on your PATH too

## Setup — one command

```bash
chmod +x setup-android.sh
./setup-android.sh
```

This installs dependencies, builds the web app, syncs it into `android/`, regenerates the Gradle wrapper if missing, and builds a debug APK at:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

## Manual steps (equivalent, if you'd rather run them yourself)

```bash
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug   # if ./gradlew is missing: gradle wrapper --gradle-version 8.7
```

## Opening in Android Studio instead

```bash
npx cap open android
```
Android Studio will offer to fix/regenerate the Gradle wrapper automatically on first open if anything's missing, then you can build → Build Bundle(s)/APK(s) → Build APK(s) from the menu, or hit Run to install on a device/emulator.

## Signing a release APK

The debug APK above is unsigned for release purposes — fine for testing on your own device. For a Play Store release build, you'll need to generate a keystore and configure `android/app/build.gradle` `signingConfigs`, then run `./gradlew assembleRelease`. Android Studio's Build → Generate Signed Bundle/APK wizard does this interactively if you prefer not to edit Gradle by hand.
