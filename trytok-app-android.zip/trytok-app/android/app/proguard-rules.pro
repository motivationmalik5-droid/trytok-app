# Add project specific ProGuard rules here.
-keep public class * extends com.getcapacitor.Plugin
-keep public class com.getcapacitor.** { *; }
