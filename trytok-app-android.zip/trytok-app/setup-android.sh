#!/bin/bash
# Run this ONCE on your own machine (needs internet + Node.js + a JDK).
# It installs Capacitor, regenerates the Gradle wrapper (the one binary
# piece that can't be hand-authored offline), and does the first sync
# + debug build.
set -e

echo "→ Installing dependencies..."
npm install

echo "→ Building the web app..."
npm run build

echo "→ Syncing web assets + plugins into android/..."
npx cap sync android

# gradlew / gradlew.bat are already included. Only the wrapper JAR
# (a compiled binary) couldn't be generated offline. Fetch/regenerate it:
if [ ! -f "android/gradle/wrapper/gradle-wrapper.jar" ]; then
  echo "→ gradle-wrapper.jar missing, generating it..."
  if command -v gradle >/dev/null 2>&1; then
    (cd android && gradle wrapper --gradle-version 8.7)
  else
    echo "   No local 'gradle' command found."
    echo "   Easiest fix: open android/ in Android Studio once —"
    echo "   it detects the missing jar and regenerates it automatically."
    echo "   (Or install Gradle locally and re-run this script.)"
    exit 1
  fi
  chmod +x android/gradlew
fi

echo "→ Building debug APK..."
(cd android && ./gradlew assembleDebug)

echo "✅ Done. APK at: android/app/build/outputs/apk/debug/app-debug.apk"
echo "   Or open the project in Android Studio: npx cap open android"
