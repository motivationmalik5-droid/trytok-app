/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        "trytok-bg": "#0A0A0F",
        "trytok-coral": "#FF4D6D",
        "trytok-violet": "#7C5CFC",
      },
    },
  },
  plugins: [],
};
