# TryTok API Documentation

Base URL: `https://api.trytok.com/v1`
Auth: Bearer JWT access token in `Authorization: Bearer <token>` header, unless noted as public.
All responses are JSON. Errors follow: `{ "error": { "code": "string", "message": "string" } }`

---

## 1. Authentication

### POST /auth/register
Create an account via email or phone.
```json
// Request
{ "method": "email", "email": "user@example.com", "password": "••••••••" }
// or
{ "method": "phone", "phone": "+11234567890", "password": "••••••••" }
```
```json
// Response 201
{ "user": { "id": "u_123", "username": "auto_generated" }, "accessToken": "...", "refreshToken": "..." }
```

### POST /auth/login
```json
{ "method": "email", "email": "user@example.com", "password": "••••••••" }
```
Returns `accessToken` (15 min TTL) + `refreshToken` (30 day TTL, rotating).

### POST /auth/oauth/google | /auth/oauth/apple
```json
{ "idToken": "<provider id token>" }
```
Creates or logs in a user from a verified OAuth identity.

### POST /auth/refresh
```json
{ "refreshToken": "..." }
```
Returns a new `accessToken` and rotated `refreshToken`. Old refresh token is invalidated (reuse triggers full session revocation).

### POST /auth/logout
Revokes the current refresh token.

---

## 2. Users & Profile

| Method | Endpoint | Description |
|---|---|---|
| GET | `/users/:id` | Public profile: bio, counts, verification status |
| GET | `/users/me` | Current authenticated user |
| PATCH | `/users/me` | Update name, username, bio, link, avatar |
| GET | `/users/:id/videos` | Paginated videos for a profile grid |
| GET | `/users/me/saved` | Saved videos tab |
| POST | `/users/:id/follow` | Follow (or send follow request if private) |
| DELETE | `/users/:id/follow` | Unfollow |
| GET | `/users/me/follow-requests` | Pending incoming requests |
| POST | `/users/me/follow-requests/:id/accept` | Accept |
| POST | `/users/me/follow-requests/:id/decline` | Decline |
| POST | `/users/:id/block` | Block a user |
| POST | `/users/:id/report` | `{ "reason": "harassment" }` |

---

## 3. Feed & Discovery

### GET /feed?tab=for_you|following&cursor=...
Returns a paginated, cursor-based list of ranked video posts. See §8 for ranking logic.

### GET /discover/trending
Returns `hashtags`, `sounds`, `users`, `videos` trending blocks.

### GET /search?q=...&type=top|users|hashtags|sounds|videos
Full-text + fuzzy search across entities.

---

## 4. Video Upload & Content

### POST /videos (multipart/form-data)
Fields: `file`, `caption`, `hashtags[]`, `mentions[]`, `soundId`, `thumbnailFrame`, `privacy` (`public|friends|private`), `scheduledAt` (optional ISO datetime).
Returns a `videoId` and processing status (`queued → transcoding → ready`).

### GET /videos/:id
### DELETE /videos/:id
### PATCH /videos/:id — update caption, privacy, or featured thumbnail

### GET /sounds/:id/videos — videos using a given sound

---

## 5. Social Interactions

| Method | Endpoint |
|---|---|
| POST | `/videos/:id/like` / `DELETE /videos/:id/like` |
| POST | `/videos/:id/save` / `DELETE /videos/:id/save` |
| POST | `/videos/:id/repost` |
| POST | `/videos/:id/comments` — `{ "text": "...", "parentId": null }` (nested replies via `parentId`) |
| GET | `/videos/:id/comments?sort=top|new` |
| POST | `/comments/:id/like` |
| POST | `/comments/:id/report` |
| DELETE | `/comments/:id` |

---

## 6. Messaging (Inbox)

Real-time transport: WebSocket at `wss://api.trytok.com/v1/ws` (auth via access token on connect), REST for history/setup.

| Method | Endpoint |
|---|---|
| GET | `/chats` | List of 1-1 and group threads, with `lastMessage`, `unreadCount`, `online` |
| POST | `/chats` | Create thread — `{ "participantIds": [...] }` (>2 = group) |
| GET | `/chats/:id/messages?cursor=...` | Paginated history |
| POST | `/chats/:id/messages` | `{ "type": "text"\|"image"\|"voice", "text"?, "mediaUrl"?, "durationMs"? }` |
| POST | `/chats/:id/read` | Marks thread read → triggers `read_receipt` event to sender |

**WebSocket events:** `message.new`, `typing.start`, `typing.stop`, `presence.update`, `read_receipt`.

### Push notifications
`POST /devices` registers an FCM/APNs token. Server emits pushes for: new message, like, comment, mention, new follower, follow request, live-stream-started (from followed creators).

---

## 7. Live Streaming & Monetization

| Method | Endpoint |
|---|---|
| POST | `/live/streams` | Start a stream, returns low-latency ingest URL (RTMP) + playback URL (LL-HLS/WebRTC) |
| DELETE | `/live/streams/:id` | End stream |
| POST | `/live/streams/:id/cohost` | Invite/accept a co-host |
| POST | `/live/streams/:id/moderators/:userId` | Grant moderator role |
| POST | `/live/streams/:id/viewers/:userId/mute` \| `/kick` \| `/block` | Moderator actions |
| GET | `/live/streams/:id/rankings` | Top gifters for the session |
| WS event | `live.comment`, `live.gift`, `live.viewerCount` | Real-time stream events |

### Coins & Gifts
| Method | Endpoint |
|---|---|
| GET | `/coins/packages` | Purchasable coin bundles |
| POST | `/coins/purchase` | `{ "packageId": "...", "paymentMethodId": "..." }` |
| GET | `/gifts/catalog` | Gift list with coin costs |
| POST | `/live/streams/:id/gifts` | `{ "giftId": "...", "quantity": 1 }` — deducts coins, credits recipient's diamond balance |

### Wallet & Earnings
| Method | Endpoint |
|---|---|
| GET | `/wallet` | Coin balance + diamond (earnings) balance |
| GET | `/wallet/transactions?cursor=...` | Purchases, gift spend, gift income, withdrawals |
| GET | `/creator/earnings?range=7d\|30d\|all` | Earnings dashboard aggregates + breakdown by source |
| POST | `/withdrawals` | `{ "amountUsd": 100.00, "method": "stripe"\|"paypal"\|"wise"\|"bank_transfer", "destinationId": "..." }` |
| GET | `/withdrawals/:id` | Status: `pending → processing → paid \| failed` |

---

## 8. Recommendation System

`GET /feed?tab=for_you` scores each candidate video per user as:

```
score = w1·watchTimeRatio + w2·likeRate + w3·commentRate + w4·shareRate + w5·behaviorAffinity
```

- `watchTimeRatio`: completion % and rewatch signals, strongest weight.
- `likeRate`, `commentRate`, `shareRate`: normalized per-impression engagement.
- `behaviorAffinity`: similarity between the viewer's follow graph / historical interests and the video's creator, sound, and hashtag embeddings.

Default weights: watch time 40%, likes 20%, comments 15%, shares 15%, behavior 10% — configurable per-cohort from the Admin Panel's Algorithm tab (`PATCH /admin/algorithm/weights`).

---

## 9. Admin API

All endpoints require an `admin` or `moderator` role claim in the JWT.

| Method | Endpoint | Description |
|---|---|---|
| GET | `/admin/stats/overview` | Platform KPIs (DAU, uploads, revenue, pending reports) |
| GET | `/admin/users?query=&status=` | Search/filter users |
| PATCH | `/admin/users/:id/status` | `{ "status": "suspended"\|"banned"\|"shadowbanned"\|"active" }` |
| DELETE | `/admin/users/:id` | Hard-delete an account |
| POST | `/admin/users/:id/approve-creator` | Grant verified-creator status |
| PATCH | `/admin/videos/:id` | `{ "featured": true }` or remove |
| DELETE | `/admin/videos/:id` | Take down a video |
| GET | `/admin/reports?type=user\|video\|comment` | Moderation queue |
| POST | `/admin/reports/:id/resolve` \| `/dismiss` | |
| GET | `/admin/copyright-claims` | |
| POST | `/admin/copyright-claims/:id/uphold` \| `/reject` | |
| GET | `/admin/live/streams` | Active streams, with `flagged` signal from auto-moderation |
| DELETE | `/admin/live/streams/:id` | Force-end a stream |
| GET | `/admin/withdrawals?status=pending` | |
| POST | `/admin/withdrawals/:id/approve` \| `/reject` | |
| PATCH | `/admin/algorithm/weights` | Update recommendation signal weights |

---

## 10. Errors & Rate Limits

- Standard HTTP status codes; `401` on expired/invalid access token (client should call `/auth/refresh`).
- Rate limits: 100 req/min per user on read endpoints, 20 req/min on write endpoints (uploads, gifts, withdrawals have dedicated stricter buckets).
- Idempotency: mutating endpoints accept an `Idempotency-Key` header for safe retries (recommended for `/coins/purchase`, `/withdrawals`, `/live/streams/:id/gifts`).

---

## 11. Suggested Folder Structure (backend)

```
/src
  /modules
    auth/
    users/
    feed/
    videos/
    social/        (likes, comments, saves, reports)
    messaging/
    live/
    monetization/   (coins, gifts, wallet, withdrawals)
    recommendation/
    admin/
  /common          (guards, interceptors, DTOs)
  /config
  /websocket
docs/
  openapi.yaml
```
