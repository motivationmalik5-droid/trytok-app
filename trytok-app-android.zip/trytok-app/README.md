# TryTok — Frontend

A phased React + Tailwind frontend for TryTok, a short-form vertical video app.

## What's included

| Route | Phase | Covers |
|---|---|---|
| `/` | 1 | Vertical video feed, Following/For You tabs, bottom nav, dark/light mode |
| `/auth` | 2 | Login/Register (email, phone, Google, Apple), JWT + refresh token demo, Profile, Edit Profile |
| `/create` | 3 | Upload (captions, hashtags, mentions, sound, thumbnail, privacy, scheduling), Discover/Trending search |
| `/social` | 4 | Nested comments, save/report/block, Inbox (1-1 + group chat, typing, read receipts, voice/media), Activity & follow requests |
| `/live` | 5a | Live streaming (co-host, moderators, rankings), Coins, Wallet, Creator Earnings, Withdrawal |
| `/admin` | 5b | Admin panel (users, content, reports, copyright, live, payouts) + recommendation algorithm tuner |

The top bar in the running app is a **dev-only switcher** between phases — each page is a self-contained full-screen mobile view. Wire these into your real navigation (bottom tab bar, protected routes, etc.) for production.

API contract for a backend is documented in `docs/API_Documentation.md`.

## Setup

```bash
npm install
npm run dev
```

Open the printed local URL (default `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview
```

## Stack

- React 18 + Vite
- Tailwind CSS
- React Router
- lucide-react (icons)

## Folder structure

```
trytok-app/
  index.html
  vite.config.js
  tailwind.config.js
  postcss.config.js
  package.json
  docs/
    API_Documentation.md
  src/
    main.jsx
    App.jsx
    index.css
    pages/
      Feed.jsx
      AuthProfile.jsx
      CreateExplore.jsx
      SocialInbox.jsx
      LiveMonetization.jsx
      AdminPanel.jsx
```

## Notes

- All data in these pages is mocked/placeholder (no live backend calls yet) — see `docs/API_Documentation.md` for the endpoints to wire up next.
- JWT/refresh-token behavior in `AuthProfile.jsx` is simulated client-side for demonstration; replace with real calls to `/auth/login`, `/auth/refresh`, etc.
- Design tokens: background `#0A0A0F`, coral `#FF4D6D`, violet `#7C5CFC`.
